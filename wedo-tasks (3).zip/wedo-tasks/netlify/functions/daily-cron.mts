// Netlify scheduled function: calls the app's cron endpoint once a day (00:30 UTC = 06:00 IST).
// Only needed when deploying to Netlify; Vercel uses vercel.json instead.
import type { Config } from "@netlify/functions";

export default async () => {
  const base = process.env.URL; // set automatically by Netlify
  const res = await fetch(`${base}/api/cron/daily`, { headers: { Authorization: `Bearer ${process.env.CRON_SECRET}` } });
  console.log("daily cron", res.status, await res.text());
  return new Response("ok");
};

export const config: Config = { schedule: "30 0 * * *" };
