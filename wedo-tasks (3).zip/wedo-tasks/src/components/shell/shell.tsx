"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import clsx from "clsx";
import { X } from "lucide-react";
import { Logo, Avatar } from "@/components/ui/bits";
import { useApp } from "@/components/app-context";
import { NAV } from "./nav";
import { Topbar } from "./topbar";

function SidebarNav({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();
  const { can, me } = useApp();
  const items = NAV.filter((n) => !n.perm || can(n.perm));
  return (
    <div className="flex h-full flex-col">
      <div className="px-5 py-5"><Link href="/" onClick={onNavigate}><Logo dark /></Link></div>
      <nav className="flex-1 space-y-0.5 overflow-y-auto px-3">
        {items.map((item) => {
          const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
          const Icon = item.icon;
          return (
            <div key={item.href}>
              {item.section && <p className="px-3 pb-1 pt-5 text-[11px] font-semibold uppercase tracking-wider text-sidebar-muted/70">{item.section}</p>}
              <Link
                href={item.href}
                onClick={onNavigate}
                className={clsx(
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                  active ? "bg-sidebar-active text-white" : "text-sidebar-muted hover:bg-sidebar-hover hover:text-sidebar-fg",
                )}
              >
                <Icon className="h-[18px] w-[18px]" />
                {item.label}
              </Link>
            </div>
          );
        })}
      </nav>
      <Link href="/account" onClick={onNavigate} className="m-3 flex items-center gap-3 rounded-lg p-2 hover:bg-sidebar-hover">
        <Avatar name={me.name} size={34} className="ring-sidebar" />
        <span className="min-w-0">
          <span className="block truncate text-sm font-medium text-sidebar-fg">{me.name}</span>
          <span className="block truncate text-xs text-sidebar-muted">{me.roleName}</span>
        </span>
      </Link>
    </div>
  );
}

export function Shell({ children, unread }: { children: React.ReactNode; unread: number }) {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  useEffect(() => setOpen(false), [pathname]);
  return (
    <div className="min-h-screen">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 bg-sidebar lg:block"><SidebarNav /></aside>
      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 max-w-[85%] bg-sidebar shadow-pop">
            <button aria-label="Close menu" onClick={() => setOpen(false)} className="absolute right-3 top-5 rounded-md p-1 text-sidebar-muted hover:text-white"><X className="h-5 w-5" /></button>
            <SidebarNav onNavigate={() => setOpen(false)} />
          </aside>
        </div>
      )}
      <div className="lg:pl-64">
        <Topbar onMenu={() => setOpen(true)} unread={unread} />
        <main className="mx-auto max-w-[1400px] px-4 py-5 sm:px-6 lg:px-8 lg:py-7">{children}</main>
      </div>
    </div>
  );
}
