"use client";

import { createContext, useContext } from "react";
import type { Lookups } from "@/lib/lookups";
import type { PermissionKey } from "@/lib/permissions";

export type Me = { id: string; name: string; email: string; title: string | null; roleKey: string; roleName: string; departmentIds: string[]; permissions: PermissionKey[] };
type AppData = { me: Me; lookups: Lookups };

const Ctx = createContext<AppData | null>(null);

export function AppProvider({ value, children }: { value: AppData; children: React.ReactNode }) {
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useApp must be used inside AppProvider");
  const can = (p: PermissionKey) => v.me.permissions.includes(p);
  return { ...v, can };
}
