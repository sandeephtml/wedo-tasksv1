"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import clsx from "clsx";
import { ChevronDown, ChevronRight, MessageSquare, CheckSquare, Calendar, ClipboardList } from "lucide-react";
import { useApp } from "@/components/app-context";
import { useToast } from "@/components/ui/toast";
import { EmptyState } from "@/components/ui/bits";
import { formatDay, isOverdue, todayDate } from "@/lib/dates";
import { setTaskAssignees } from "@/app/actions/tasks";
import type { TaskRow } from "@/lib/task-queries";
import { StatusSelect, PriorityBadge } from "./status-pill";
import { UserPicker } from "./user-picker";
import { useStatusChange } from "./use-status-change";

export function TaskList({ rows, setRows }: { rows: TaskRow[]; setRows: React.Dispatch<React.SetStateAction<TaskRow[]>> }) {
  const { lookups, can } = useApp();
  const toast = useToast();
  const { change, dialog } = useStatusChange(rows, setRows);
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const today = todayDate();
  const doneIds = useMemo(() => new Set(lookups.statuses.filter((s) => s.category === "DONE").map((s) => s.id)), [lookups.statuses]);
  const clientName = (id: string | null) => lookups.clients.find((c) => c.id === id)?.name;
  const deptName = (id: string | null) => lookups.departments.find((d) => d.id === id)?.name;

  const groups = useMemo(
    () =>
      lookups.priorities.map((p) => ({
        priority: p,
        tasks: rows
          .filter((r) => r.priorityId === p.id)
          .sort((a, b) => (a.dueDate ?? "9999").localeCompare(b.dueDate ?? "9999") || a.number - b.number),
      })),
    [rows, lookups.priorities],
  );

  const changeAssignees = async (task: TaskRow, ids: string[]) => {
    const prev = rows;
    setRows((rs) => rs.map((r) => (r.id === task.id ? { ...r, assigneeIds: ids } : r)));
    const res = await setTaskAssignees(task.id, ids).catch(() => ({ ok: false as const, error: "Couldn't reach the server. Change undone." }));
    if (!res.ok) { setRows(prev); toast.error(res.error); }
  };

  if (!rows.length) {
    return <div className="card"><EmptyState icon={<ClipboardList className="h-10 w-10" />} title="No tasks here">Try changing the filters, or create a new task.</EmptyState></div>;
  }

  return (
    <div className="space-y-4">
      {dialog}
      {groups.filter((g) => g.tasks.length).map(({ priority, tasks }) => {
        const isCollapsed = collapsed[priority.id];
        return (
          <section key={priority.id} className="card overflow-visible">
            <button onClick={() => setCollapsed((c) => ({ ...c, [priority.id]: !c[priority.id] }))} className="flex w-full items-center gap-2 border-b border-line px-4 py-3 text-left">
              {isCollapsed ? <ChevronRight className="h-4 w-4 text-ink-faint" /> : <ChevronDown className="h-4 w-4 text-ink-faint" />}
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: priority.color }} />
              <span className="font-semibold">{priority.name}</span>
              <span className="rounded-full bg-page px-2 py-0.5 text-xs text-ink-muted">{tasks.length}</span>
            </button>
            {!isCollapsed && (
              <>
                <div className="hidden grid-cols-[minmax(0,1fr)_120px_110px_160px] gap-4 border-b border-line bg-page/60 px-4 py-2 text-[11px] font-semibold uppercase tracking-wide text-ink-faint md:grid">
                  <span>Task</span><span>Assignees</span><span>Due</span><span>Status</span>
                </div>
                <ul className="divide-y divide-line">
                  {tasks.map((t) => {
                    const overdue = isOverdue(t.dueDate, doneIds.has(t.statusId), today);
                    const done = doneIds.has(t.statusId);
                    const meta = [clientName(t.clientId) ?? "Internal", deptName(t.departmentId)].filter(Boolean).join(" · ");
                    return (
                      <li key={t.id} className={clsx("grid grid-cols-1 gap-2 px-4 py-3 md:grid-cols-[minmax(0,1fr)_120px_110px_160px] md:items-center md:gap-4", overdue && "bg-danger-soft/30")}>
                        <div className="min-w-0">
                          <Link href={`/tasks/${t.id}`} className={clsx("block truncate font-medium hover:text-brand", done && "text-ink-muted line-through")}>{t.title}</Link>
                          <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-ink-muted">
                            <span className="text-ink-faint">#{t.number}</span>
                            <span className="truncate">{meta}</span>
                            {t.checklistTotal > 0 && <span className="flex items-center gap-1"><CheckSquare className="h-3 w-3" />{t.checklistDone}/{t.checklistTotal}</span>}
                            {t.commentCount > 0 && <span className="flex items-center gap-1"><MessageSquare className="h-3 w-3" />{t.commentCount}</span>}
                            <span className="md:hidden"><PriorityBadge id={t.priorityId} /></span>
                          </div>
                        </div>
                        <div className="flex items-center justify-between gap-3 md:contents">
                          <div><UserPicker variant="inline" value={t.assigneeIds} onChange={(ids) => changeAssignees(t, ids)} disabled={!can("task.assign")} departmentId={t.departmentId} /></div>
                          <div className={clsx("flex items-center gap-1 text-xs", overdue ? "font-semibold text-danger" : "text-ink-muted")}>
                            {t.dueDate ? <><Calendar className="h-3.5 w-3.5" />{formatDay(t.dueDate)}{overdue && " · overdue"}</> : <span className="text-ink-faint">No date</span>}
                          </div>
                          <div><StatusSelect value={t.statusId} onChange={(id) => change(t.id, id)} label={`Status of ${t.title}`} /></div>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </>
            )}
          </section>
        );
      })}
    </div>
  );
}
