"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import clsx from "clsx";
import { Check, ChevronDown, Search } from "lucide-react";
import { Avatar, AvatarStack } from "@/components/ui/bits";
import { useApp } from "@/components/app-context";

/** Searchable multi-select of active users. `variant="inline"` renders a compact avatar trigger for list rows. */
export function UserPicker({
  value, onChange, placeholder = "Select people", disabled, variant = "field", departmentId, exclude = [], label,
}: {
  value: string[]; onChange: (ids: string[]) => void; placeholder?: string; disabled?: boolean;
  variant?: "field" | "inline"; departmentId?: string | null; exclude?: string[]; label?: string;
}) {
  const { lookups } = useApp();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [open]);

  const users = useMemo(() => {
    const list = lookups.users.filter((u) => !exclude.includes(u.id) && u.name.toLowerCase().includes(q.toLowerCase()));
    // Department members first.
    return departmentId ? [...list].sort((a, b) => Number(b.departmentIds.includes(departmentId)) - Number(a.departmentIds.includes(departmentId))) : list;
  }, [lookups.users, q, departmentId, exclude]);
  const names = value.map((id) => lookups.users.find((u) => u.id === id)?.name).filter(Boolean) as string[];
  const toggle = (id: string) => onChange(value.includes(id) ? value.filter((x) => x !== id) : [...value, id]);

  return (
    <div
      className="relative"
      ref={ref}
      onKeyDown={(e) => {
        // Close only the dropdown, not a surrounding modal.
        if (e.key === "Escape" && open) { e.preventDefault(); setOpen(false); }
      }}
    >
      {variant === "field" ? (
        <button type="button" aria-label={label ?? placeholder} disabled={disabled} onClick={() => setOpen((o) => !o)} className="input flex min-h-[38px] items-center justify-between gap-2 text-left">
          {names.length ? (
            <span className="flex min-w-0 items-center gap-2"><AvatarStack names={names} max={4} size={22} /><span className="truncate text-ink">{names.join(", ")}</span></span>
          ) : (
            <span className="text-ink-faint">{placeholder}</span>
          )}
          <ChevronDown className="h-4 w-4 shrink-0 text-ink-faint" />
        </button>
      ) : (
        <button type="button" aria-label={label ?? "Change assignees"} disabled={disabled} onClick={() => setOpen((o) => !o)} className={clsx("rounded-md p-0.5", !disabled && "hover:bg-page")}>
          <AvatarStack names={names} size={24} />
        </button>
      )}
      {open && (
        <div className="absolute left-0 z-40 mt-1 w-64 rounded-xl border border-line bg-surface p-1 shadow-pop">
          <div className="relative p-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-faint" />
            <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search people" className="input h-8 pl-8 text-xs" />
          </div>
          <div className="max-h-60 overflow-y-auto">
            {users.map((u) => (
              <button key={u.id} type="button" onClick={() => toggle(u.id)} className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-sm hover:bg-page">
                <Avatar name={u.name} size={24} />
                <span className="min-w-0 flex-1"><span className="block truncate">{u.name}</span>{u.title && <span className="block truncate text-[11px] text-ink-faint">{u.title}</span>}</span>
                {value.includes(u.id) && <Check className="h-4 w-4 text-brand" />}
              </button>
            ))}
            {!users.length && <p className="px-2 py-3 text-center text-xs text-ink-muted">No matches</p>}
          </div>
        </div>
      )}
    </div>
  );
}
