"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Plus, Trash2, Link2 } from "lucide-react";
import { Modal } from "@/components/ui/modal";
import { useApp } from "@/components/app-context";
import { useToast } from "@/components/ui/toast";
import { createTask, updateTask } from "@/app/actions/tasks";
import { UserPicker } from "./user-picker";

export type TaskFormValues = {
  title: string; description: string; clientId: string; departmentId: string; priorityId: string; statusId: string;
  startDate: string; dueDate: string; estimateHours: string; assigneeIds: string[]; collaboratorIds: string[];
};

export function TaskFormModal({
  open, onClose, taskId, initial,
}: { open: boolean; onClose: () => void; taskId?: string; initial?: Partial<TaskFormValues> }) {
  const { lookups, can, me } = useApp();
  const toast = useToast();
  const router = useRouter();
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const editing = !!taskId;
  const defaults: TaskFormValues = {
    title: "", description: "", clientId: "", priorityId: lookups.priorities.find((p) => p.isDefault)?.id ?? lookups.priorities[0]?.id ?? "",
    departmentId: me.departmentIds.length === 1 ? me.departmentIds[0]! : "",
    statusId: "", startDate: "", dueDate: "", estimateHours: "",
    assigneeIds: can("task.assign") ? [] : [me.id], collaboratorIds: [],
  };
  const [v, setV] = useState<TaskFormValues>({ ...defaults, ...initial });
  const [checklist, setChecklist] = useState<string[]>([]);
  const [newItem, setNewItem] = useState("");
  const [links, setLinks] = useState<{ url: string; label: string }[]>([]);
  const set = <K extends keyof TaskFormValues>(k: K, val: TaskFormValues[K]) => setV((s) => ({ ...s, [k]: val }));
  const statusOptions = lookups.statuses.filter((s) => can("task.approve") || (s.category !== "DONE" && s.category !== "REVISION"));

  const submit = () => {
    setError(null);
    const pendingItem = newItem.trim();
    start(async () => {
      const payload = {
        ...v,
        statusId: v.statusId || null,
        checklist: pendingItem ? [...checklist, pendingItem] : checklist,
        links: links.filter((l) => l.url.trim()),
      };
      const res = editing ? await updateTask(taskId!, payload) : await createTask(payload);
      if (!res.ok) return setError(res.error);
      toast.success(editing ? "Task updated" : "Task created");
      onClose();
      if (!editing) {
        setV({ ...defaults, ...initial }); setChecklist([]); setLinks([]); setNewItem("");
        const id = (res.data as { id: string } | undefined)?.id;
        if (id) router.push(`/tasks/${id}`);
      }
      router.refresh();
    });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={editing ? "Edit task" : "Create task"}
      size="lg"
      footer={
        <>
          <button className="btn-secondary" onClick={onClose}>Cancel</button>
          <button className="btn-primary" disabled={pending || !v.title.trim()} onClick={submit}>
            {pending && <Loader2 className="h-4 w-4 animate-spin" />} {editing ? "Save changes" : "Create task"}
          </button>
        </>
      }
    >
      <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); submit(); }}>
        <div>
          <label className="label" htmlFor="t-title">Title *</label>
          <input id="t-title" className="input text-base" value={v.title} onChange={(e) => set("title", e.target.value)} placeholder="e.g. Monthly SEO report for BarrierBreak" maxLength={200} />
        </div>
        <div>
          <label className="label" htmlFor="t-desc">Description</label>
          <textarea id="t-desc" rows={4} className="input" value={v.description} onChange={(e) => set("description", e.target.value)} placeholder="Brief, goals, references…" />
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="t-client">Client</label>
            <select id="t-client" className="input" value={v.clientId} onChange={(e) => set("clientId", e.target.value)}>
              <option value="">Internal (no client)</option>
              {lookups.clients.map((c) => <option key={c.id} value={c.id}>{c.name}{c.status !== "ACTIVE" ? ` (${c.status === "ON_HOLD" ? "on hold" : "upcoming"})` : ""}</option>)}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="t-dept">Department</label>
            <select id="t-dept" className="input" value={v.departmentId} onChange={(e) => set("departmentId", e.target.value)}>
              <option value="">—</option>
              {lookups.departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="t-prio">Priority</label>
            <select id="t-prio" className="input" value={v.priorityId} onChange={(e) => set("priorityId", e.target.value)}>
              {lookups.priorities.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          {!editing && (
            <div>
              <label className="label" htmlFor="t-status">Status</label>
              <select id="t-status" className="input" value={v.statusId} onChange={(e) => set("statusId", e.target.value)}>
                <option value="">Default ({lookups.statuses.find((s) => s.isDefault)?.name ?? "first"})</option>
                {statusOptions.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
          )}
          <div>
            <label className="label" htmlFor="t-start">Start date</label>
            <input id="t-start" type="date" className="input" value={v.startDate} onChange={(e) => set("startDate", e.target.value)} />
          </div>
          <div>
            <label className="label" htmlFor="t-due">Due date</label>
            <input id="t-due" type="date" className="input" value={v.dueDate} min={v.startDate || undefined} onChange={(e) => set("dueDate", e.target.value)} />
          </div>
          <div>
            <label className="label" htmlFor="t-est">Estimate (hours)</label>
            <input id="t-est" type="number" min={0} max={1000} step={0.25} className="input" value={v.estimateHours} onChange={(e) => set("estimateHours", e.target.value)} />
          </div>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <span className="label">Assignees</span>
            <UserPicker label="Assignees" value={v.assigneeIds} onChange={(ids) => set("assigneeIds", ids)} departmentId={v.departmentId} disabled={!can("task.assign")} placeholder="Assign people" />
            {!can("task.assign") && <p className="mt-1 text-[11px] text-ink-faint">Tasks you create are assigned to you.</p>}
          </div>
          <div>
            <span className="label">Collaborators</span>
            <UserPicker label="Collaborators" value={v.collaboratorIds} onChange={(ids) => set("collaboratorIds", ids)} departmentId={v.departmentId} exclude={v.assigneeIds} placeholder="Add collaborators" />
          </div>
        </div>

        {!editing && (
          <>
            <div>
              <span className="label">Checklist</span>
              <ul className="mb-2 space-y-1">
                {checklist.map((c, i) => (
                  <li key={i} className="flex items-center gap-2 rounded-lg bg-page px-3 py-1.5 text-sm">
                    <span className="flex-1">{c}</span>
                    <button type="button" aria-label="Remove item" onClick={() => setChecklist((l) => l.filter((_, j) => j !== i))} className="text-ink-faint hover:text-danger"><Trash2 className="h-3.5 w-3.5" /></button>
                  </li>
                ))}
              </ul>
              <div className="flex gap-2">
                <input className="input" value={newItem} onChange={(e) => setNewItem(e.target.value)} placeholder="Add a checklist item"
                  onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); if (newItem.trim()) { setChecklist((l) => [...l, newItem.trim()]); setNewItem(""); } } }} />
                <button type="button" className="btn-secondary" onClick={() => { if (newItem.trim()) { setChecklist((l) => [...l, newItem.trim()]); setNewItem(""); } }}><Plus className="h-4 w-4" /></button>
              </div>
            </div>
            <div>
              <span className="label">Links (Google Drive, references)</span>
              <div className="space-y-2">
                {links.map((l, i) => (
                  <div key={i} className="flex gap-2">
                    <input className="input" placeholder="https://drive.google.com/…" value={l.url} onChange={(e) => setLinks((ls) => ls.map((x, j) => (j === i ? { ...x, url: e.target.value } : x)))} />
                    <input className="input max-w-[40%]" placeholder="Label" value={l.label} onChange={(e) => setLinks((ls) => ls.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)))} />
                    <button type="button" aria-label="Remove link" className="btn-ghost px-2" onClick={() => setLinks((ls) => ls.filter((_, j) => j !== i))}><Trash2 className="h-4 w-4" /></button>
                  </div>
                ))}
                <button type="button" className="btn-ghost btn-sm" onClick={() => setLinks((ls) => [...ls, { url: "", label: "" }])}><Link2 className="h-3.5 w-3.5" /> Add link</button>
              </div>
            </div>
          </>
        )}
        {error && <p role="alert" className="rounded-lg bg-danger-soft px-3 py-2 text-sm text-danger">{error}</p>}
        <button type="submit" className="hidden" />
      </form>
    </Modal>
  );
}
