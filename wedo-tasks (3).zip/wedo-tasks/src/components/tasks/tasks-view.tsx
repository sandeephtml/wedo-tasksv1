"use client";

import { useEffect, useState, useTransition } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import clsx from "clsx";
import { LayoutList, KanbanSquare, X, Loader2 } from "lucide-react";
import { useApp } from "@/components/app-context";
import type { TaskRow } from "@/lib/task-queries";
import { TaskList } from "./task-list";
import { TaskBoard } from "./task-board";

function FilterSelect({ name, label, options, value, onChange }: { name: string; label: string; options: { value: string; label: string }[]; value: string; onChange: (k: string, v: string) => void }) {
  return (
    <select aria-label={label} value={value} onChange={(e) => onChange(name, e.target.value)} className={clsx("input h-9 w-auto min-w-0 max-w-[180px] py-1.5 text-xs", value && "border-brand bg-brand-soft text-brand")}>
      <option value="">{label}</option>
      {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
}

export function TasksView({ rows: initialRows, hideAssignee, lockedClientId }: { rows: TaskRow[]; hideAssignee?: boolean; lockedClientId?: string }) {
  const { lookups } = useApp();
  const router = useRouter();
  const pathname = usePathname();
  const sp = useSearchParams();
  const [pending, start] = useTransition();
  const [rows, setRows] = useState(initialRows);
  useEffect(() => setRows(initialRows), [initialRows]);

  const view = sp.get("view") === "board" ? "board" : "list";
  const showCompleted = sp.get("completed") === "1";
  const set = (k: string, v: string) => {
    const p = new URLSearchParams(sp.toString());
    if (v) p.set(k, v); else p.delete(k);
    start(() => router.replace(`${pathname}?${p.toString()}`, { scroll: false }));
  };
  const activeFilters = ["q", "client", "department", "priority", "assignee", "due", "status"].filter((k) => sp.get(k));

  return (
    <div>
      <div className="mb-4 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap items-center gap-2">
          {!lockedClientId && (
            <FilterSelect name="client" label="All clients" value={sp.get("client") ?? ""} onChange={set}
              options={[{ value: "none", label: "Internal (no client)" }, ...lookups.clients.map((c) => ({ value: c.id, label: c.name }))]} />
          )}
          <FilterSelect name="department" label="All departments" value={sp.get("department") ?? ""} onChange={set} options={lookups.departments.map((d) => ({ value: d.id, label: d.name }))} />
          <FilterSelect name="priority" label="Any priority" value={sp.get("priority") ?? ""} onChange={set} options={lookups.priorities.map((p) => ({ value: p.id, label: p.name }))} />
          {!hideAssignee && (
            <FilterSelect name="assignee" label="Anyone" value={sp.get("assignee") ?? ""} onChange={set}
              options={[{ value: "me", label: "Assigned to me" }, { value: "none", label: "Unassigned" }, ...lookups.users.map((u) => ({ value: u.id, label: u.name }))]} />
          )}
          <FilterSelect name="due" label="Any due date" value={sp.get("due") ?? ""} onChange={set}
            options={[{ value: "overdue", label: "Overdue" }, { value: "today", label: "Due today" }, { value: "next7", label: "Next 7 days" }, { value: "none", label: "No due date" }]} />
          {activeFilters.length > 0 && (
            <button className="btn-ghost btn-sm" onClick={() => {
              const p = new URLSearchParams();
              if (sp.get("view")) p.set("view", sp.get("view")!);
              if (showCompleted) p.set("completed", "1");
              start(() => router.replace(`${pathname}?${p.toString()}`, { scroll: false }));
            }}><X className="h-3.5 w-3.5" /> Clear</button>
          )}
          {pending && <Loader2 className="h-4 w-4 animate-spin text-ink-faint" />}
        </div>
        <div className="flex items-center gap-3">
          <label className="flex cursor-pointer items-center gap-2 text-xs font-medium text-ink-muted">
            <input type="checkbox" className="h-4 w-4 rounded border-line text-brand accent-[rgb(var(--brand))]" checked={showCompleted} onChange={(e) => set("completed", e.target.checked ? "1" : "")} />
            Show completed
          </label>
          <div className="flex rounded-lg border border-line bg-surface p-0.5">
            <button onClick={() => set("view", "")} className={clsx("flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium", view === "list" ? "bg-brand text-brand-fg" : "text-ink-muted hover:text-ink")}><LayoutList className="h-3.5 w-3.5" /> List</button>
            <button onClick={() => set("view", "board")} className={clsx("flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium", view === "board" ? "bg-brand text-brand-fg" : "text-ink-muted hover:text-ink")}><KanbanSquare className="h-3.5 w-3.5" /> Board</button>
          </div>
        </div>
      </div>
      {sp.get("q") && <p className="mb-3 text-sm text-ink-muted">Results for “{sp.get("q")}” · <button className="text-brand hover:underline" onClick={() => set("q", "")}>clear search</button></p>}
      {view === "board" ? <TaskBoard rows={rows} setRows={setRows} showCompleted={showCompleted} /> : <TaskList rows={rows} setRows={setRows} />}
    </div>
  );
}
