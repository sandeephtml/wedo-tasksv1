// Pure review-workflow rules (unit tested in tests/workflow.test.ts).
import type { StatusCategory } from "@prisma/client";

export type WorkflowActor = { canApprove: boolean; canEditAny: boolean; isInvolved: boolean };

/**
 * Returns an error message if the move is not allowed, otherwise null.
 * - Only approvers may complete (DONE) or send back (REVISION) a task; a revision needs a comment.
 * - Once a task is under review, only approvers may move it.
 * - Reopening a completed task needs approval rights.
 * - Otherwise anyone involved in the task (assignee/collaborator/creator) or with edit rights may move it.
 */
export function checkStatusChange(
  actor: WorkflowActor,
  from: StatusCategory,
  to: StatusCategory,
  comment?: string | null,
): string | null {
  if (!actor.canApprove && !actor.canEditAny && !actor.isInvolved) {
    return "Only people working on this task can change its status.";
  }
  if (to === "DONE" && !actor.canApprove) {
    return "Submit the task for review — a manager will approve it.";
  }
  if (to === "REVISION") {
    if (!actor.canApprove) return "Only managers can request revisions.";
    if (!comment || !comment.trim()) return "Please add a comment explaining the revision needed.";
  }
  if (from === "REVIEW" && !actor.canApprove) {
    return "This task is waiting for review. Only a manager can move it now.";
  }
  if (from === "DONE" && !actor.canApprove) {
    return "Only managers can reopen a completed task.";
  }
  return null;
}
