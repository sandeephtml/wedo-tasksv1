// Pure recurrence maths for recurring tasks (unit tested).
import type { Frequency } from "@prisma/client";
import { addDays } from "./dates";

export type RecurrenceRule = { frequency: Frequency; weekday?: number | null; monthDay?: number | null };

/** First occurrence on/after `from` (UTC date-only). */
export function firstRunOnOrAfter(rule: RecurrenceRule, from: Date): Date {
  if (rule.frequency === "DAILY") return from;
  if (rule.frequency === "WEEKLY") {
    const wd = rule.weekday ?? 1;
    const diff = (wd - from.getUTCDay() + 7) % 7;
    return addDays(from, diff);
  }
  const md = Math.min(Math.max(rule.monthDay ?? 1, 1), 28);
  const candidate = new Date(Date.UTC(from.getUTCFullYear(), from.getUTCMonth(), md));
  if (candidate.getTime() >= from.getTime()) return candidate;
  return new Date(Date.UTC(from.getUTCFullYear(), from.getUTCMonth() + 1, md));
}

/** Next occurrence strictly after `last`. */
export function nextRunAfter(rule: RecurrenceRule, last: Date): Date {
  return firstRunOnOrAfter(rule, addDays(last, 1));
}
