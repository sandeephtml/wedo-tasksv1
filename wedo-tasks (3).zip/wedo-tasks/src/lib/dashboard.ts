import "server-only";
import { prisma } from "./db";
import { addDays, todayDate } from "./dates";
import { bucketOf } from "./status-buckets";

/** Monday-based week windows relative to `today` (UTC date-only). */
export function deadlineWindows(today: Date) {
  const tomorrow = addDays(today, 1);
  const dow = (today.getUTCDay() + 6) % 7; // 0 = Monday
  const endOfWeek = addDays(today, 6 - dow); // Sunday
  const nextWeekStart = addDays(endOfWeek, 1);
  const nextWeekEnd = addDays(endOfWeek, 7);
  return { today, tomorrow, endOfWeek, nextWeekStart, nextWeekEnd };
}

export async function getDashboard() {
  const today = todayDate();
  const w = deadlineWindows(today);
  const since30 = addDays(today, -30);

  const [activeClients, teamMembers, statuses, departments, users, tasks, activity] = await Promise.all([
    prisma.client.count({ where: { status: "ACTIVE" } }),
    prisma.user.count({ where: { isActive: true } }),
    prisma.taskStatus.findMany(),
    prisma.department.findMany({ orderBy: { name: "asc" } }),
    prisma.user.findMany({ where: { isActive: true }, orderBy: { name: "asc" }, select: { id: true, name: true, title: true } }),
    prisma.task.findMany({
      select: {
        id: true, title: true, number: true, dueDate: true, completedAt: true, statusId: true, departmentId: true, priorityId: true,
        client: { select: { name: true } }, assignees: { select: { userId: true } },
      },
    }),
    prisma.activity.findMany({ orderBy: { createdAt: "desc" }, take: 20, include: { actor: { select: { name: true } } } }),
  ]);

  const statusById = new Map(statuses.map((s) => [s.id, s]));
  const bucket = (statusId: string) => bucketOf(statusById.get(statusId)!);
  const isDone = (t: { statusId: string }) => bucket(t.statusId) === "done";
  const overdue = (t: { dueDate: Date | null; statusId: string }) => !!t.dueDate && t.dueDate < today && !isDone(t);

  const counts = {
    total: tasks.length,
    pending: tasks.filter((t) => bucket(t.statusId) === "pending").length,
    inProgress: tasks.filter((t) => bucket(t.statusId) === "in_progress").length,
    onHold: tasks.filter((t) => bucket(t.statusId) === "on_hold").length,
    completed: tasks.filter(isDone).length,
    overdue: tasks.filter(overdue).length,
    review: tasks.filter((t) => statusById.get(t.statusId)?.category === "REVIEW").length,
  };

  const deptCards = departments.map((d) => {
    const t = tasks.filter((x) => x.departmentId === d.id);
    const done = t.filter(isDone).length;
    return { id: d.id, name: d.name, color: d.color, total: t.length, done, overdue: t.filter(overdue).length, pct: t.length ? Math.round((done / t.length) * 100) : 0 };
  });

  const team = users.map((u) => {
    const mine = tasks.filter((t) => t.assignees.some((a) => a.userId === u.id));
    const done = mine.filter(isDone);
    const doneRecent = done.filter((t) => t.completedAt && t.completedAt >= since30);
    const onTime = done.filter((t) => t.completedAt && (!t.dueDate || t.completedAt <= addDays(t.dueDate, 1)));
    return {
      id: u.id, name: u.name, title: u.title,
      open: mine.length - done.length,
      inProgress: mine.filter((t) => bucket(t.statusId) === "in_progress").length,
      review: mine.filter((t) => statusById.get(t.statusId)?.category === "REVIEW").length,
      overdue: mine.filter(overdue).length,
      completed30: doneRecent.length,
      onTimePct: done.length ? Math.round((onTime.length / done.length) * 100) : null,
    };
  });

  const open = tasks.filter((t) => !isDone(t) && t.dueDate);
  const pick = (from: Date, to: Date) =>
    open.filter((t) => t.dueDate! >= from && t.dueDate! <= to).sort((a, b) => a.dueDate!.getTime() - b.dueDate!.getTime());
  const userName = new Map(users.map((u) => [u.id, u.name]));
  const toItem = (t: (typeof tasks)[number]) => ({
    id: t.id, number: t.number, title: t.title, client: t.client?.name ?? null, dueDate: t.dueDate!.toISOString(), statusId: t.statusId, priorityId: t.priorityId,
    assignees: t.assignees.map((a) => userName.get(a.userId)).filter(Boolean) as string[],
  });
  const deadlines = [
    { key: "today", label: "Today", items: pick(w.today, w.today).map(toItem) },
    { key: "tomorrow", label: "Tomorrow", items: pick(w.tomorrow, w.tomorrow).map(toItem) },
    { key: "week", label: "Later this week", items: w.endOfWeek > w.tomorrow ? pick(addDays(w.tomorrow, 1), w.endOfWeek).map(toItem) : [] },
    { key: "next", label: "Next week", items: pick(w.nextWeekStart, w.nextWeekEnd).map(toItem) },
  ];

  return { counts, activeClients, teamMembers, deptCards, team, deadlines, activity };
}
