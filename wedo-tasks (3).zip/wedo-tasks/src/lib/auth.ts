import "server-only";
import { cache } from "react";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { prisma } from "./db";
import { SESSION_COOKIE, verifySession } from "./session";
import type { PermissionKey, RoleKey } from "./permissions";

export type CurrentUser = {
  id: string;
  name: string;
  email: string;
  title: string | null;
  roleKey: RoleKey;
  roleName: string;
  roleRank: number;
  mustChangePassword: boolean;
  departmentIds: string[];
  permissions: Set<PermissionKey>;
};

/** Loads the signed-in user from the DB on every request (deactivation/reset take effect immediately). */
export const getCurrentUser = cache(async (): Promise<CurrentUser | null> => {
  const store = await cookies();
  const session = await verifySession(store.get(SESSION_COOKIE)?.value);
  if (!session) return null;

  const user = await prisma.user.findUnique({
    where: { id: session.sub },
    include: {
      role: { include: { permissions: { include: { permission: true } } } },
      departments: { select: { departmentId: true } },
    },
  });
  if (!user || !user.isActive || user.sessionVersion !== session.sv) return null;

  return {
    id: user.id,
    name: user.name,
    email: user.email,
    title: user.title,
    roleKey: user.role.key as RoleKey,
    roleName: user.role.name,
    roleRank: user.role.rank,
    mustChangePassword: user.mustChangePassword,
    departmentIds: user.departments.map((d) => d.departmentId),
    permissions: new Set(user.role.permissions.map((rp) => rp.permission.key as PermissionKey)),
  };
});

export function can(user: CurrentUser | null, permission: PermissionKey) {
  return !!user && user.permissions.has(permission);
}

/** For pages: redirect to /login if not signed in. */
export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}

/** For pages: render 403 page if permission missing. */
export async function requirePagePermission(permission: PermissionKey) {
  const user = await requireUser();
  if (!can(user, permission)) redirect("/forbidden");
  return user;
}

export class ActionError extends Error {}

/** For server actions: throws ActionError (turned into a friendly message) when not allowed. */
export async function requireActionUser(permission?: PermissionKey) {
  const user = await getCurrentUser();
  if (!user) throw new ActionError("Your session has expired. Please sign in again.");
  if (permission && !can(user, permission)) throw new ActionError("You don't have permission to do that.");
  return user;
}
