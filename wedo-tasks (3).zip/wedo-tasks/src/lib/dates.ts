// Date helpers. Due/start dates are stored as SQL DATE (UTC midnight). "Today" is computed in
// the agency's timezone so a task due today isn't flagged overdue at 5:30am IST.

export const APP_TZ = process.env.APP_TIMEZONE || process.env.NEXT_PUBLIC_APP_TIMEZONE || "Asia/Kolkata";

export function todayStr(tz = APP_TZ, now = new Date()) {
  return new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(now);
}

export function dateFromStr(s: string) {
  return new Date(`${s}T00:00:00.000Z`);
}

export function todayDate(tz = APP_TZ, now = new Date()) {
  return dateFromStr(todayStr(tz, now));
}

export function addDays(d: Date, n: number) {
  const x = new Date(d);
  x.setUTCDate(x.getUTCDate() + n);
  return x;
}

export function toInputDate(d: Date | string | null | undefined) {
  if (!d) return "";
  return new Date(d).toISOString().slice(0, 10);
}

/** Format a date-only value ("12 Nov" or "12 Nov 2027" when not this year). */
export function formatDay(d: Date | string | null | undefined) {
  if (!d) return "";
  const date = new Date(d);
  const sameYear = date.getUTCFullYear() === new Date().getUTCFullYear();
  return new Intl.DateTimeFormat("en-GB", {
    day: "numeric",
    month: "short",
    ...(sameYear ? {} : { year: "numeric" }),
    timeZone: "UTC",
  }).format(date);
}

/** Format a timestamp in the agency timezone. */
export function formatDateTime(d: Date | string, tz = APP_TZ) {
  return new Intl.DateTimeFormat("en-GB", {
    day: "numeric",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
    timeZone: tz,
  }).format(new Date(d));
}

export function timeAgo(d: Date | string, now = new Date()) {
  const s = Math.max(0, Math.round((now.getTime() - new Date(d).getTime()) / 1000));
  if (s < 60) return "just now";
  const m = Math.round(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h ago`;
  const days = Math.round(h / 24);
  if (days < 30) return `${days}d ago`;
  return formatDay(d);
}

export function isOverdue(due: Date | string | null | undefined, isDone: boolean, today = todayDate()) {
  return !!due && !isDone && new Date(due).getTime() < today.getTime();
}

export function plural(n: number, word: string, pluralWord = `${word}s`) {
  return `${n} ${n === 1 ? word : pluralWord}`;
}
