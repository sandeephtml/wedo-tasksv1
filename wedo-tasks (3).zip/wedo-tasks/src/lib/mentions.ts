// "@Neha" or "@neha" matches a user whose first name (or full name without spaces) is Neha.
export function findMentionedUserIds(text: string, users: { id: string; name: string }[]): string[] {
  const tokens = new Set([...text.matchAll(/(?:^|[^\w@])@([A-Za-z][\w.-]{0,40})/g)].map((m) => m[1]!.toLowerCase().replace(/[.-]+$/, "")));
  if (!tokens.size) return [];
  const ids = new Set<string>();
  for (const u of users) {
    const first = u.name.split(/\s+/)[0]!.toLowerCase();
    const full = u.name.replace(/\s+/g, "").toLowerCase();
    if (tokens.has(first) || tokens.has(full)) ids.add(u.id);
  }
  return [...ids];
}
