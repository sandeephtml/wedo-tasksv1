import { ZodError } from "zod";
import { unstable_rethrow } from "next/navigation";
import { ActionError } from "./auth";

export type ActionResult<T = undefined> = { ok: true; data?: T; message?: string } | { ok: false; error: string };

/** Wraps a server action body: maps validation/permission errors to friendly messages. */
export async function runAction<T>(fn: () => Promise<T>): Promise<ActionResult<T>> {
  try {
    const data = await fn();
    return { ok: true, data };
  } catch (e) {
    unstable_rethrow(e);
    if (e instanceof ActionError) return { ok: false, error: e.message };
    if (e instanceof ZodError) {
      const issue = e.issues[0];
      const field = issue?.path?.join(".");
      return { ok: false, error: issue ? (field ? `${field}: ${issue.message}` : issue.message) : "Invalid input" };
    }
    console.error("[action]", e);
    return { ok: false, error: "Something went wrong. Please try again." };
  }
}
