import { z } from "zod";

export const passwordSchema = z
  .string()
  .min(10, "Password must be at least 10 characters")
  .max(128, "Password is too long")
  .regex(/[A-Za-z]/, "Password must include a letter")
  .regex(/[0-9]/, "Password must include a number");

const emptyToNull = (v: unknown) => (typeof v === "string" && v.trim() === "" ? null : v);

export const idSchema = z.string().min(1).max(64);
export const optionalId = z.preprocess(emptyToNull, idSchema.nullable().optional());
export const optionalText = (max = 5000) => z.preprocess(emptyToNull, z.string().trim().max(max).nullable().optional());
export const dateString = z.preprocess(
  emptyToNull,
  z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use YYYY-MM-DD").nullable().optional(),
);
export const urlSchema = z
  .string()
  .trim()
  .max(2000)
  .transform((v) => (/^https?:\/\//i.test(v) ? v : `https://${v}`))
  .pipe(z.string().url("Enter a valid URL"));
export const optionalUrl = z.preprocess(emptyToNull, urlSchema.nullable().optional());

export const taskInputSchema = z
  .object({
    title: z.string().trim().min(1, "Title is required").max(200),
    description: optionalText(20000),
    clientId: optionalId,
    departmentId: optionalId,
    priorityId: idSchema,
    statusId: optionalId,
    startDate: dateString,
    dueDate: dateString,
    estimateHours: z.preprocess(
      (v) => (v === "" || v === null || v === undefined ? null : Number(v)),
      z.number().min(0).max(1000).nullable(),
    ),
    assigneeIds: z.array(idSchema).max(30).default([]),
    collaboratorIds: z.array(idSchema).max(30).default([]),
    checklist: z.array(z.string().trim().min(1).max(500)).max(100).default([]),
    links: z.array(z.object({ url: urlSchema, label: optionalText(200) })).max(50).default([]),
  })
  .refine((t) => !t.startDate || !t.dueDate || t.startDate <= t.dueDate, {
    message: "Due date must be on or after the start date",
    path: ["dueDate"],
  });
export type TaskInput = z.input<typeof taskInputSchema>;

export const SERVICES = [
  "SEO", "GEO", "Local SEO", "Technical SEO", "Google Ads", "Meta Ads", "Reddit Ads", "LinkedIn Ads",
  "Content", "Social Media", "LinkedIn", "Creative", "AI Video", "Web Development", "Email Marketing",
] as const;

export const clientInputSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(120),
  website: optionalUrl,
  status: z.enum(["ACTIVE", "ON_HOLD", "UPCOMING"]),
  services: z.array(z.string().trim().min(1).max(60)).max(30).default([]),
  notes: optionalText(10000),
});
export type ClientInput = z.input<typeof clientInputSchema>;

export const hexColor = z.string().regex(/^#[0-9a-fA-F]{6}$/, "Use a hex colour like #3B82F6");
