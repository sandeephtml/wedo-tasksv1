import "server-only";
import { prisma } from "./db";
import { addDays, formatDay, todayDate } from "./dates";
import { nextRunAfter } from "./recurrence";
import { logActivity, notify } from "./events";

/** Creates due recurring tasks. Safe to run repeatedly: each template is claimed with a conditional update. */
export async function generateRecurringTasks(today = todayDate()) {
  const due = await prisma.recurringTask.findMany({
    where: { isActive: true, nextRunOn: { lte: today } },
    include: { assignees: { select: { userId: true, user: { select: { isActive: true } } } } },
  });
  const defaultStatus =
    (await prisma.taskStatus.findFirst({ where: { isDefault: true } })) ?? (await prisma.taskStatus.findFirstOrThrow({ orderBy: { order: "asc" } }));
  let created = 0;

  for (const r of due) {
    // If the cron was down for a while we create one task for today rather than a backlog of copies.
    const runOn = today;
    const next = nextRunAfter(r, today);
    const assigneeIds = r.assignees.filter((a) => a.user.isActive).map((a) => a.userId);
    const made = await prisma.$transaction(async (tx) => {
      const claim = await tx.recurringTask.updateMany({ where: { id: r.id, nextRunOn: r.nextRunOn }, data: { nextRunOn: next, lastRunOn: runOn } });
      if (claim.count === 0) return null; // another run already took it
      const max = await tx.task.aggregate({ where: { statusId: defaultStatus.id }, _max: { position: true } });
      const task = await tx.task.create({
        data: {
          title: `${r.title} — ${formatDay(runOn)}`,
          description: r.description,
          clientId: r.clientId, departmentId: r.departmentId, priorityId: r.priorityId, statusId: defaultStatus.id,
          startDate: runOn, dueDate: addDays(runOn, r.dueInDays),
          position: (max._max.position ?? 0) + 1024,
          createdById: r.createdById, recurringId: r.id,
          assignees: { create: assigneeIds.map((userId) => ({ userId })) },
          checklist: { create: r.checklist.map((text, order) => ({ text, order })) },
        },
      });
      await logActivity({ type: "task.created", message: `created recurring task "${task.title}"`, actorId: null, taskId: task.id, clientId: task.clientId }, tx);
      await notify(assigneeIds, { type: "ASSIGNED", title: `New recurring task: "${task.title}"`, body: `Due ${formatDay(task.dueDate!)}`, taskId: task.id }, tx);
      return task;
    });
    if (made) created++;
  }
  return { checked: due.length, created };
}

/** One overdue alert per task per due date (deduplicated by a unique key). */
export async function sendOverdueNotifications(today = todayDate()) {
  const tasks = await prisma.task.findMany({
    where: { dueDate: { lt: today }, status: { category: { not: "DONE" } } },
    select: { id: true, title: true, dueDate: true, createdById: true, assignees: { select: { userId: true } } },
  });
  const data = tasks.flatMap((t) => {
    const recipients = t.assignees.length ? t.assignees.map((a) => a.userId) : [t.createdById];
    return recipients.map((userId) => ({
      userId, type: "OVERDUE" as const, taskId: t.id,
      title: `"${t.title}" is overdue`, body: `It was due ${formatDay(t.dueDate!)}`,
      dedupeKey: `overdue:${t.id}:${t.dueDate!.toISOString().slice(0, 10)}`,
    }));
  });
  if (!data.length) return { overdueTasks: 0, notified: 0 };
  const res = await prisma.notification.createMany({ data, skipDuplicates: true });
  return { overdueTasks: tasks.length, notified: res.count };
}

/** Housekeeping: drop old login attempts so the table stays small. */
export async function cleanup() {
  const res = await prisma.loginAttempt.deleteMany({ where: { createdAt: { lt: addDays(new Date(), -30) } } });
  return { loginAttemptsDeleted: res.count };
}
