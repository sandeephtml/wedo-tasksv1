import { NextResponse, type NextRequest } from "next/server";
import { SESSION_COOKIE, verifySession } from "@/lib/session";

// First line of defence: no valid signed cookie → /login. Every server action and page also
// re-checks the user (active, session version, permissions) against the database.
const PUBLIC_PATHS = ["/login"];

export async function middleware(req: NextRequest) {
  const { pathname, search } = req.nextUrl;
  const session = await verifySession(req.cookies.get(SESSION_COOKIE)?.value);
  const isPublic = PUBLIC_PATHS.some((p) => pathname === p || pathname.startsWith(`${p}/`));

  if (!session && !isPublic) {
    if (pathname.startsWith("/api/")) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.search = pathname !== "/" ? `?next=${encodeURIComponent(pathname + search)}` : "";
    return NextResponse.redirect(url);
  }
  // Note: we deliberately don't bounce signed-in users away from /login here — a validly signed
  // but revoked session (deactivated user, password reset) would loop. The login page checks the DB.

  const headers = new Headers(req.headers);
  headers.set("x-pathname", pathname);
  return NextResponse.next({ request: { headers } });
}

export const config = {
  // Skip static assets, the cron endpoint (own CRON_SECRET check) and the public health check.
  matcher: ["/((?!_next/static|_next/image|favicon.ico|icon.svg|api/cron|api/health).*)"],
};
