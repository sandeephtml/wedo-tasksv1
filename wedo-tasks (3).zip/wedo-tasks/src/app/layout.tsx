import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "WeDo Tasks — We Do Marketing", template: "%s · WeDo Tasks" },
  description: "Internal task and to-do platform for WedoMarketing.",
  robots: { index: false, follow: false },
};

export const viewport: Viewport = { themeColor: "#4F46E5", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
