import Link from "next/link";
import { ShieldAlert } from "lucide-react";

export default function Forbidden() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-6 text-center">
      <ShieldAlert className="h-10 w-10 text-ink-faint" />
      <h1 className="mt-3 font-display text-xl font-semibold">You don&apos;t have access to this page</h1>
      <p className="mt-1 text-sm text-ink-muted">Ask an admin if you think you should.</p>
      <Link href="/" className="btn-primary mt-5">Go home</Link>
    </main>
  );
}
