import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { PageHeader } from "@/components/ui/bits";
import { ChangePasswordForm } from "./change-password-form";

export const metadata: Metadata = { title: "My account" };

export default async function AccountPage({ searchParams }: { searchParams: Promise<{ first?: string }> }) {
  const user = await requireUser();
  const { first } = await searchParams;
  return (
    <div className="max-w-xl">
      <PageHeader title="My account" subtitle={`${user.name} · ${user.roleName}`} />
      {(first || user.mustChangePassword) && (
        <div className="mb-4 rounded-lg border border-warning/30 bg-warning-soft px-4 py-3 text-sm text-warning">
          Please choose a new password before continuing. Your current one was set by an admin.
        </div>
      )}
      <div className="card p-5">
        <dl className="mb-6 grid grid-cols-1 gap-3 text-sm sm:grid-cols-2">
          <div><dt className="text-ink-faint">Email</dt><dd className="font-medium">{user.email}</dd></div>
          <div><dt className="text-ink-faint">Role</dt><dd className="font-medium">{user.roleName}</dd></div>
          {user.title && <div><dt className="text-ink-faint">Title</dt><dd className="font-medium">{user.title}</dd></div>}
        </dl>
        <h2 className="mb-3 font-display font-semibold">Change password</h2>
        <ChangePasswordForm mustChange={user.mustChangePassword} />
      </div>
    </div>
  );
}
