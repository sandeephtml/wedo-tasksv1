"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { changeOwnPassword } from "@/app/actions/auth";
import { useToast } from "@/components/ui/toast";

export function ChangePasswordForm({ mustChange }: { mustChange: boolean }) {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const toast = useToast();
  const router = useRouter();

  return (
    <form
      className="space-y-3"
      onSubmit={(e) => {
        e.preventDefault();
        setError(null);
        if (next !== confirm) return setError("New passwords don't match.");
        start(async () => {
          const r = await changeOwnPassword({ current, next });
          if (!r.ok) return setError(r.error);
          toast.success("Password updated. Other devices have been signed out.");
          setCurrent(""); setNext(""); setConfirm("");
          router.push(mustChange ? "/" : "/account");
          router.refresh();
        });
      }}
    >
      <div><label className="label" htmlFor="cur">Current password</label><input id="cur" type="password" autoComplete="current-password" className="input" value={current} onChange={(e) => setCurrent(e.target.value)} required /></div>
      <div><label className="label" htmlFor="new">New password</label><input id="new" type="password" autoComplete="new-password" className="input" value={next} onChange={(e) => setNext(e.target.value)} required minLength={10} />
        <p className="mt-1 text-xs text-ink-faint">At least 10 characters, with a letter and a number.</p></div>
      <div><label className="label" htmlFor="conf">Confirm new password</label><input id="conf" type="password" autoComplete="new-password" className="input" value={confirm} onChange={(e) => setConfirm(e.target.value)} required /></div>
      {error && <p role="alert" className="rounded-lg bg-danger-soft px-3 py-2 text-sm text-danger">{error}</p>}
      <button className="btn-primary" disabled={pending}>{pending && <Loader2 className="h-4 w-4 animate-spin" />} Update password</button>
    </form>
  );
}
