"use client";

import { AlertTriangle } from "lucide-react";

export default function AppError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="card mx-auto mt-10 max-w-md p-8 text-center">
      <AlertTriangle className="mx-auto h-10 w-10 text-warning" />
      <h1 className="mt-3 font-display text-lg font-semibold">Something went wrong</h1>
      <p className="mt-1 text-sm text-ink-muted">Please try again. If it keeps happening, share this code with an admin: {error.digest ?? "n/a"}</p>
      <button className="btn-primary mt-5" onClick={reset}>Try again</button>
    </div>
  );
}
