import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Globe } from "lucide-react";
import { prisma } from "@/lib/db";
import { can, requireUser } from "@/lib/auth";
import { visibleClientsWhere, visibleTasksWhere } from "@/lib/task-access";
import { listTasks, parseFilters } from "@/lib/task-queries";
import { timeAgo, todayDate } from "@/lib/dates";
import { bucketOf } from "@/lib/status-buckets";
import { Avatar, ClientStatusBadge } from "@/components/ui/bits";
import { ClientFormButton } from "@/components/clients/client-form";
import { ClientStatusSwitcher } from "./status-switcher";
import { TasksView } from "@/components/tasks/tasks-view";
import { CreateTaskButton } from "@/components/tasks/create-task-button";

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const [{ id }, user] = await Promise.all([params, requireUser()]);
  const c = await prisma.client.findFirst({ where: { AND: [{ id }, visibleClientsWhere(user)] }, select: { name: true } });
  return { title: c?.name ?? "Client" };
}

export default async function ClientPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const user = await requireUser();
  const { id } = await params;
  const client = await prisma.client.findFirst({ where: { AND: [{ id }, visibleClientsWhere(user)] } });
  if (!client) notFound();

  const today = todayDate();
  const base = { AND: [visibleTasksWhere(user), { clientId: client.id }] };
  const filters = { ...parseFilters(await searchParams), client: client.id };
  const [rows, byCategory, statusCounts, overdue, activity] = await Promise.all([
    listTasks(user, filters),
    prisma.task.groupBy({ by: ["statusId"], where: base, _count: true }),
    prisma.taskStatus.findMany({ select: { id: true, key: true, category: true } }),
    prisma.task.count({ where: { AND: [...base.AND, { dueDate: { lt: today } }, { status: { category: { not: "DONE" } } }] } }),
    prisma.activity.findMany({
      where: { clientId: client.id, ...(can(user, "task.view_all") ? {} : { OR: [{ taskId: null }, { task: visibleTasksWhere(user) }] }) },
      orderBy: { createdAt: "desc" }, take: 25, include: { actor: { select: { name: true } } },
    }),
  ]);
  const countWhere = (pred: (s: { key: string; category: string }) => boolean) =>
    byCategory.filter((g) => { const s = statusCounts.find((x) => x.id === g.statusId); return s && pred(s); }).reduce((a, g) => a + g._count, 0);
  const stats = [
    { label: "Total", value: countWhere(() => true), cls: "text-ink" },
    { label: "Pending", value: countWhere((s) => bucketOf(s) === "pending"), cls: "text-warning" },
    { label: "In progress", value: countWhere((s) => bucketOf(s) === "in_progress"), cls: "text-brand" },
    { label: "Done", value: countWhere((s) => bucketOf(s) === "done"), cls: "text-success" },
    { label: "Overdue", value: overdue, cls: "text-danger" },
  ];

  return (
    <>
      <Link href="/clients" className="btn-ghost btn-sm -ml-2 mb-3"><ArrowLeft className="h-4 w-4" /> Clients</Link>
      <div className="card mb-5 p-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-center gap-4">
            <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-brand-soft font-display text-2xl font-bold text-brand">{client.name[0]}</span>
            <div>
              <div className="flex flex-wrap items-center gap-2"><h1 className="font-display text-xl font-semibold sm:text-2xl">{client.name}</h1><ClientStatusBadge status={client.status} /></div>
              {client.website && <a href={client.website} target="_blank" rel="noopener noreferrer" className="mt-0.5 flex items-center gap-1 text-sm text-brand hover:underline"><Globe className="h-3.5 w-3.5" />{client.website.replace(/^https?:\/\//, "")}</a>}
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {can(user, "client.manage") && (
              <>
                <ClientStatusSwitcher id={client.id} status={client.status} />
                <ClientFormButton client={{ id: client.id, name: client.name, website: client.website ?? "", status: client.status, services: client.services, notes: client.notes ?? "" }} />
              </>
            )}
            {can(user, "task.create") && <CreateTaskButton initial={{ clientId: client.id }} label="Add task" />}
          </div>
        </div>
        {client.services.length > 0 && <div className="mt-4 flex flex-wrap gap-1.5">{client.services.map((s) => <span key={s} className="badge bg-brand-soft text-brand">{s}</span>)}</div>}
        {client.notes && <p className="mt-4 whitespace-pre-wrap rounded-lg bg-page p-3 text-sm text-ink-muted">{client.notes}</p>}
        <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-5">
          {stats.map((s) => (
            <div key={s.label} className="rounded-lg border border-line p-3">
              <p className="text-xs text-ink-muted">{s.label}</p>
              <p className={`font-display text-2xl font-semibold ${s.cls}`}>{s.value}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_320px]">
        <div className="min-w-0">
          <h2 className="mb-3 font-display text-lg font-semibold">Tasks</h2>
          <TasksView rows={rows} lockedClientId={client.id} />
        </div>
        <aside className="card h-fit p-4">
          <h2 className="mb-3 text-sm font-semibold">Activity</h2>
          <ul className="space-y-3">
            {activity.map((a) => (
              <li key={a.id} className="flex gap-2 text-xs">
                <Avatar name={a.actor?.name ?? "System"} size={22} />
                <div><span className="font-medium">{a.actor?.name ?? "System"}</span> <span className="text-ink-muted">{a.message}</span><span className="block text-ink-faint">{timeAgo(a.createdAt)}</span></div>
              </li>
            ))}
            {!activity.length && <li className="text-xs text-ink-faint">No activity yet.</li>}
          </ul>
        </aside>
      </div>
    </>
  );
}
