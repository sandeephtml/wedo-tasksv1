import type { Metadata } from "next";
import { prisma } from "@/lib/db";
import { can, requirePagePermission } from "@/lib/auth";
import { timeAgo } from "@/lib/dates";
import { TeamTable } from "./team-table";

export const metadata: Metadata = { title: "Team" };

export default async function TeamPage() {
  const me = await requirePagePermission("team.view");
  const manage = can(me, "user.manage");
  const [users, roles] = await Promise.all([
    prisma.user.findMany({
      where: manage ? {} : { isActive: true },
      orderBy: [{ isActive: "desc" }, { role: { rank: "desc" } }, { name: "asc" }],
      include: {
        role: true,
        departments: { select: { departmentId: true } },
        _count: { select: { assignedTasks: { where: { task: { status: { category: { not: "DONE" } } } } } } },
      },
    }),
    prisma.role.findMany({ orderBy: { rank: "desc" } }),
  ]);
  const rows = users.map((u) => ({
    id: u.id, name: u.name, email: u.email, title: u.title ?? "", roleId: u.roleId, roleName: u.role.name, roleRank: u.role.rank,
    departmentIds: u.departments.map((d) => d.departmentId), isActive: u.isActive, mustChangePassword: u.mustChangePassword,
    lastLogin: u.lastLoginAt ? timeAgo(u.lastLoginAt) : "Never", openTasks: u._count.assignedTasks,
  }));
  return (
    <>
      <TeamTable
        users={rows}
        roles={roles.map((r) => ({ id: r.id, name: r.name, rank: r.rank }))}
        meId={me.id}
        meRank={me.roleRank}
        canManage={manage}
        canManageAdmins={can(me, "user.manage_admins")}
      />
    </>
  );
}
