import type { Metadata } from "next";
import { prisma } from "@/lib/db";
import { requirePagePermission } from "@/lib/auth";
import { toInputDate } from "@/lib/dates";
import { RecurringList } from "./recurring-list";

export const metadata: Metadata = { title: "Recurring tasks" };

export default async function RecurringPage() {
  await requirePagePermission("recurring.manage");
  const items = await prisma.recurringTask.findMany({
    orderBy: [{ isActive: "desc" }, { nextRunOn: "asc" }],
    include: { assignees: { select: { userId: true } }, _count: { select: { tasks: true } } },
  });
  return (
    <RecurringList
      items={items.map((r) => ({
        id: r.id, title: r.title, description: r.description ?? "", clientId: r.clientId ?? "", departmentId: r.departmentId ?? "",
        priorityId: r.priorityId, frequency: r.frequency, weekday: r.weekday, monthDay: r.monthDay, dueInDays: r.dueInDays,
        checklist: r.checklist, assigneeIds: r.assignees.map((a) => a.userId), isActive: r.isActive,
        nextRunOn: toInputDate(r.nextRunOn), lastRunOn: r.lastRunOn ? toInputDate(r.lastRunOn) : null, generated: r._count.tasks,
      }))}
    />
  );
}
