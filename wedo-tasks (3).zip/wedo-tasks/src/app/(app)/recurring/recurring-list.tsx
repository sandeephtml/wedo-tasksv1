"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import clsx from "clsx";
import { Loader2, Pause, Pencil, Play, Plus, Repeat, Trash2 } from "lucide-react";
import { AvatarStack, EmptyState, PageHeader } from "@/components/ui/bits";
import { Modal } from "@/components/ui/modal";
import { useApp } from "@/components/app-context";
import { useToast } from "@/components/ui/toast";
import { UserPicker } from "@/components/tasks/user-picker";
import { PriorityBadge } from "@/components/tasks/status-pill";
import { formatDay } from "@/lib/dates";
import { deleteRecurring, saveRecurring, setRecurringActive } from "@/app/actions/recurring";

type Item = {
  id: string; title: string; description: string; clientId: string; departmentId: string; priorityId: string; frequency: "DAILY" | "WEEKLY" | "MONTHLY";
  weekday: number | null; monthDay: number | null; dueInDays: number; checklist: string[]; assigneeIds: string[]; isActive: boolean;
  nextRunOn: string; lastRunOn: string | null; generated: number;
};
const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const describe = (i: Pick<Item, "frequency" | "weekday" | "monthDay">) =>
  i.frequency === "DAILY" ? "Every day" : i.frequency === "WEEKLY" ? `Every ${DAYS[i.weekday ?? 1]}` : `Monthly on day ${i.monthDay}`;

export function RecurringList({ items }: { items: Item[] }) {
  const { lookups } = useApp();
  const [edit, setEdit] = useState<Item | "new" | null>(null);
  const [del, setDel] = useState<Item | null>(null);
  const [pending, start] = useTransition();
  const toast = useToast();
  const router = useRouter();
  const nameOf = (id: string) => lookups.users.find((u) => u.id === id)?.name ?? "";

  return (
    <>
      <PageHeader title="Recurring tasks" subtitle="Templates that automatically create tasks every day, week or month (runs daily at 6:00 am IST)."
        actions={<button className="btn-primary" onClick={() => setEdit("new")}><Plus className="h-4 w-4" /> New recurring task</button>} />
      {items.length ? (
        <div className="card divide-y divide-line">
          {items.map((i) => (
            <div key={i.id} className={clsx("flex flex-col gap-3 p-4 sm:flex-row sm:items-center", !i.isActive && "opacity-60")}>
              <div className="min-w-0 flex-1">
                <p className="flex flex-wrap items-center gap-2 font-medium">{i.title} <PriorityBadge id={i.priorityId} />{!i.isActive && <span className="badge bg-page text-ink-muted">Paused</span>}</p>
                <p className="mt-0.5 text-xs text-ink-muted">
                  <Repeat className="mr-1 inline h-3 w-3" />{describe(i)} · due {i.dueInDays ? `${i.dueInDays} day(s) later` : "same day"} · {lookups.clients.find((c) => c.id === i.clientId)?.name ?? "Internal"}
                  {i.isActive && <> · next: <strong>{formatDay(i.nextRunOn)}</strong></>} · {i.generated} created
                </p>
              </div>
              <AvatarStack names={i.assigneeIds.map(nameOf).filter(Boolean)} />
              <div className="flex gap-1">
                <button className="btn-ghost btn-sm" aria-label={i.isActive ? `Pause ${i.title}` : `Resume ${i.title}`} disabled={pending}
                  onClick={() => start(async () => { const r = await setRecurringActive(i.id, !i.isActive); if (!r.ok) toast.error(r.error); else router.refresh(); })}>
                  {i.isActive ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </button>
                <button className="btn-ghost btn-sm" aria-label={`Edit ${i.title}`} onClick={() => setEdit(i)}><Pencil className="h-4 w-4" /></button>
                <button className="btn-ghost btn-sm hover:text-danger" aria-label={`Delete ${i.title}`} onClick={() => setDel(i)}><Trash2 className="h-4 w-4" /></button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="card"><EmptyState icon={<Repeat className="h-10 w-10" />} title="No recurring tasks yet">Set up monthly reports, weekly audits or daily checks once and let them generate automatically.</EmptyState></div>
      )}
      {edit && <RecurringForm item={edit === "new" ? null : edit} onClose={() => setEdit(null)} />}
      <Modal open={!!del} onClose={() => setDel(null)} title="Delete recurring task?" size="sm"
        footer={<><button className="btn-secondary" onClick={() => setDel(null)}>Cancel</button><button className="btn-danger" disabled={pending} onClick={() => start(async () => {
          const r = await deleteRecurring(del!.id); setDel(null); if (!r.ok) toast.error(r.error); else { toast.success("Deleted"); router.refresh(); }
        })}>Delete</button></>}>
        <p className="text-sm text-ink-muted">No more tasks will be created from “{del?.title}”. Tasks already created are kept.</p>
      </Modal>
    </>
  );
}

function RecurringForm({ item, onClose }: { item: Item | null; onClose: () => void }) {
  const { lookups } = useApp();
  const toast = useToast();
  const router = useRouter();
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [v, setV] = useState({
    title: item?.title ?? "", description: item?.description ?? "", clientId: item?.clientId ?? "", departmentId: item?.departmentId ?? "",
    priorityId: item?.priorityId ?? lookups.priorities.find((p) => p.isDefault)?.id ?? lookups.priorities[0]?.id ?? "",
    frequency: item?.frequency ?? ("MONTHLY" as Item["frequency"]), weekday: item?.weekday ?? 1, monthDay: item?.monthDay ?? 1,
    dueInDays: item?.dueInDays ?? 3, startOn: "", assigneeIds: item?.assigneeIds ?? [], checklist: (item?.checklist ?? []).join("\n"),
  });
  const save = () => start(async () => {
    setError(null);
    const r = await saveRecurring(item?.id ?? null, { ...v, checklist: v.checklist.split("\n").map((s) => s.trim()).filter(Boolean) });
    if (!r.ok) return setError(r.error);
    toast.success("Recurring task saved"); onClose(); router.refresh();
  });
  return (
    <Modal open onClose={onClose} title={item ? "Edit recurring task" : "New recurring task"} size="lg"
      footer={<><button className="btn-secondary" onClick={onClose}>Cancel</button><button className="btn-primary" disabled={pending || !v.title.trim()} onClick={save}>{pending && <Loader2 className="h-4 w-4 animate-spin" />} Save</button></>}>
      <div className="space-y-4">
        <div><label className="label" htmlFor="r-title">Title *</label><input id="r-title" className="input" value={v.title} onChange={(e) => setV({ ...v, title: e.target.value })} placeholder="e.g. Monthly SEO report" />
          <p className="mt-1 text-[11px] text-ink-faint">The date is added automatically, e.g. “Monthly SEO report — 1 Nov”.</p></div>
        <div><label className="label" htmlFor="r-desc">Description</label><textarea id="r-desc" rows={3} className="input" value={v.description} onChange={(e) => setV({ ...v, description: e.target.value })} /></div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div><label className="label" htmlFor="r-freq">Repeats</label>
            <select id="r-freq" className="input" value={v.frequency} onChange={(e) => setV({ ...v, frequency: e.target.value as Item["frequency"] })}>
              <option value="DAILY">Daily</option><option value="WEEKLY">Weekly</option><option value="MONTHLY">Monthly</option>
            </select></div>
          {v.frequency === "WEEKLY" && <div><label className="label" htmlFor="r-wd">On</label><select id="r-wd" className="input" value={v.weekday} onChange={(e) => setV({ ...v, weekday: Number(e.target.value) })}>{DAYS.map((d, i) => <option key={d} value={i}>{d}</option>)}</select></div>}
          {v.frequency === "MONTHLY" && <div><label className="label" htmlFor="r-md">Day of month</label><select id="r-md" className="input" value={v.monthDay} onChange={(e) => setV({ ...v, monthDay: Number(e.target.value) })}>{Array.from({ length: 28 }, (_, i) => <option key={i + 1} value={i + 1}>{i + 1}</option>)}</select></div>}
          <div><label className="label" htmlFor="r-due">Due after (days)</label><input id="r-due" type="number" min={0} max={60} className="input" value={v.dueInDays} onChange={(e) => setV({ ...v, dueInDays: Number(e.target.value) })} /></div>
          <div><label className="label" htmlFor="r-start">Start from</label><input id="r-start" type="date" className="input" value={v.startOn} onChange={(e) => setV({ ...v, startOn: e.target.value })} /></div>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div><label className="label" htmlFor="r-client">Client</label><select id="r-client" className="input" value={v.clientId} onChange={(e) => setV({ ...v, clientId: e.target.value })}><option value="">Internal</option>{lookups.clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
          <div><label className="label" htmlFor="r-dept">Department</label><select id="r-dept" className="input" value={v.departmentId} onChange={(e) => setV({ ...v, departmentId: e.target.value })}><option value="">—</option>{lookups.departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
          <div><label className="label" htmlFor="r-prio">Priority</label><select id="r-prio" className="input" value={v.priorityId} onChange={(e) => setV({ ...v, priorityId: e.target.value })}>{lookups.priorities.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
        </div>
        <div><span className="label">Assignees</span><UserPicker label="Assignees" value={v.assigneeIds} onChange={(ids) => setV({ ...v, assigneeIds: ids })} departmentId={v.departmentId} /></div>
        <div><label className="label" htmlFor="r-check">Checklist (one item per line)</label><textarea id="r-check" rows={4} className="input" value={v.checklist} onChange={(e) => setV({ ...v, checklist: e.target.value })} /></div>
        {error && <p role="alert" className="rounded-lg bg-danger-soft px-3 py-2 text-sm text-danger">{error}</p>}
      </div>
    </Modal>
  );
}
