import type { Metadata } from "next";
import Link from "next/link";
import clsx from "clsx";
import { prisma } from "@/lib/db";
import { can, requirePagePermission } from "@/lib/auth";
import { formatDateTime } from "@/lib/dates";
import { PERMISSIONS } from "@/lib/permissions";
import { PageHeader } from "@/components/ui/bits";
import { ConfigList, RolesMatrix } from "./settings-client";

export const metadata: Metadata = { title: "Settings" };

export default async function SettingsPage({ searchParams }: { searchParams: Promise<{ tab?: string; page?: string }> }) {
  const me = await requirePagePermission("settings.manage");
  const { tab = "statuses", page } = await searchParams;
  const tabs = [
    { key: "statuses", label: "Statuses" }, { key: "priorities", label: "Priorities" }, { key: "roles", label: "Roles & permissions" },
    ...(can(me, "audit.view") ? [{ key: "audit", label: "Audit log" }] : []),
  ];
  const active = tabs.find((t) => t.key === tab)?.key ?? "statuses";

  let body: React.ReactNode = null;
  if (active === "statuses") {
    const statuses = await prisma.taskStatus.findMany({ orderBy: { order: "asc" }, include: { _count: { select: { tasks: true } } } });
    body = <ConfigList kind="status" items={statuses.map((s) => ({ id: s.id, name: s.name, color: s.color, category: s.category, isDefault: s.isDefault, uses: s._count.tasks }))} />;
  } else if (active === "priorities") {
    const priorities = await prisma.priority.findMany({ orderBy: { order: "asc" }, include: { _count: { select: { tasks: true } } } });
    body = <ConfigList kind="priority" items={priorities.map((p) => ({ id: p.id, name: p.name, color: p.color, isDefault: p.isDefault, uses: p._count.tasks }))} />;
  } else if (active === "roles") {
    const roles = await prisma.role.findMany({ orderBy: { rank: "desc" }, include: { permissions: { include: { permission: true } }, _count: { select: { users: true } } } });
    body = (
      <RolesMatrix
        permissions={Object.entries(PERMISSIONS).map(([key, p]) => ({ key, ...p }))}
        roles={roles.map((r) => ({
          id: r.id, key: r.key, name: r.name, description: r.description, users: r._count.users,
          keys: r.permissions.map((p) => p.permission.key),
          editable: r.key !== "SUPER_ADMIN" && (me.roleKey === "SUPER_ADMIN" || r.rank < me.roleRank),
        }))}
      />
    );
  } else {
    const p = Math.max(1, Number(page) || 1);
    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({ orderBy: { createdAt: "desc" }, skip: (p - 1) * 50, take: 50, include: { actor: { select: { name: true } } } }),
      prisma.auditLog.count(),
    ]);
    body = (
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px]">
            <thead className="bg-page/60"><tr><th className="table-th">When</th><th className="table-th">Who</th><th className="table-th">Action</th><th className="table-th">Details</th></tr></thead>
            <tbody className="divide-y divide-line">
              {logs.map((l) => (
                <tr key={l.id} className="align-top">
                  <td className="table-td whitespace-nowrap text-xs text-ink-muted">{formatDateTime(l.createdAt)}</td>
                  <td className="table-td whitespace-nowrap">{l.actor?.name ?? "—"}</td>
                  <td className="table-td"><code className="rounded bg-page px-1.5 py-0.5 text-xs">{l.action}</code></td>
                  <td className="table-td"><pre className="max-w-xl whitespace-pre-wrap break-all font-mono text-[11px] text-ink-muted">{l.details ? JSON.stringify(l.details) : ""}</pre></td>
                </tr>
              ))}
              {!logs.length && <tr><td colSpan={4} className="table-td py-10 text-center text-ink-faint">No admin actions recorded yet.</td></tr>}
            </tbody>
          </table>
        </div>
        {total > 50 && (
          <div className="flex justify-between border-t border-line px-4 py-3 text-sm">
            {p > 1 ? <Link className="text-brand" href={`/settings?tab=audit&page=${p - 1}`}>← Newer</Link> : <span />}
            {p * 50 < total ? <Link className="text-brand" href={`/settings?tab=audit&page=${p + 1}`}>Older →</Link> : <span />}
          </div>
        )}
      </div>
    );
  }

  return (
    <>
      <PageHeader title="Settings" subtitle="Workflow configuration and access control" />
      <div className="mb-5 flex gap-1 overflow-x-auto rounded-lg border border-line bg-surface p-1 sm:w-fit">
        {tabs.map((t) => (
          <Link key={t.key} href={`/settings?tab=${t.key}`} className={clsx("whitespace-nowrap rounded-md px-3 py-1.5 text-sm font-medium", active === t.key ? "bg-brand text-brand-fg" : "text-ink-muted hover:text-ink")}>{t.label}</Link>
        ))}
      </div>
      {body}
    </>
  );
}
