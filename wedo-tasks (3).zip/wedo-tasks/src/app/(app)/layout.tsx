import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { getLookups } from "@/lib/lookups";
import { prisma } from "@/lib/db";
import { AppProvider } from "@/components/app-context";
import { ToastProvider } from "@/components/ui/toast";
import { Shell } from "@/components/shell/shell";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  const pathname = (await headers()).get("x-pathname") ?? "";
  if (user.mustChangePassword && pathname !== "/account") redirect("/account?first=1");

  const [lookups, unread] = await Promise.all([
    getLookups(),
    prisma.notification.count({ where: { userId: user.id, readAt: null } }),
  ]);
  const me = {
    id: user.id, name: user.name, email: user.email, title: user.title, roleKey: user.roleKey,
    roleName: user.roleName, departmentIds: user.departmentIds, permissions: [...user.permissions],
  };
  return (
    <AppProvider value={{ me, lookups }}>
      <ToastProvider>
        <Shell unread={unread}>{children}</Shell>
      </ToastProvider>
    </AppProvider>
  );
}
