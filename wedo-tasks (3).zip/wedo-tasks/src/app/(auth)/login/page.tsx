import type { Metadata } from "next";
import { CheckCircle2 } from "lucide-react";
import { Logo } from "@/components/ui/bits";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { LoginForm } from "./login-form";

export const metadata: Metadata = { title: "Sign in" };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next } = await searchParams;
  if (await getCurrentUser()) redirect("/");
  return (
    <main className="grid min-h-screen lg:grid-cols-2">
      <section className="relative hidden flex-col justify-between overflow-hidden bg-sidebar p-10 text-sidebar-fg lg:flex">
        <div className="absolute -right-24 -top-24 h-80 w-80 rounded-full bg-brand/30 blur-3xl" />
        <div className="absolute -bottom-32 -left-20 h-96 w-96 rounded-full bg-accent/20 blur-3xl" />
        <Logo dark />
        <div className="relative max-w-md">
          <h1 className="font-display text-3xl font-bold leading-tight">Every client task, every deadline, one place.</h1>
          <p className="mt-3 text-sidebar-muted">The internal workspace for the WedoMarketing team: SEO, performance, creative, content and web.</p>
          <ul className="mt-8 space-y-3 text-sm">
            {["Assign work across departments", "Review & approve deliverables", "Never miss a client deadline"].map((t) => (
              <li key={t} className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-accent" />{t}</li>
            ))}
          </ul>
        </div>
        <p className="relative text-xs text-sidebar-muted">© {new Date().getFullYear()} WedoMarketing · wedomarketing.io</p>
      </section>
      <section className="flex items-center justify-center px-4 py-12 sm:px-8">
        <div className="w-full max-w-sm">
          <div className="mb-8 lg:hidden"><Logo /></div>
          <h2 className="font-display text-2xl font-semibold tracking-tight">Welcome back</h2>
          <p className="mt-1 text-sm text-ink-muted">Sign in with your WedoMarketing account.</p>
          <LoginForm next={next ?? ""} />
          <p className="mt-6 text-xs text-ink-faint">Forgot your password? Ask Sandeep or Pradeep to reset it from the Team page.</p>
        </div>
      </section>
    </main>
  );
}
