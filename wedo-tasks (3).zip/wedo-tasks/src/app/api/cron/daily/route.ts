import { NextResponse } from "next/server";
import { timingSafeEqual } from "crypto";
import { cleanup, generateRecurringTasks, sendOverdueNotifications } from "@/lib/cron";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

function authorized(req: Request) {
  const secret = process.env.CRON_SECRET;
  if (!secret) return false;
  const header = req.headers.get("authorization") ?? "";
  const expected = Buffer.from(`Bearer ${secret}`);
  const got = Buffer.from(header);
  return got.length === expected.length && timingSafeEqual(got, expected);
}

// Called daily by Vercel Cron (vercel.json) or the Netlify scheduled function.
export async function GET(req: Request) {
  if (!authorized(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const recurring = await generateRecurringTasks();
  const overdue = await sendOverdueNotifications();
  const housekeeping = await cleanup();
  return NextResponse.json({ ok: true, ranAt: new Date().toISOString(), recurring, overdue, housekeeping });
}
