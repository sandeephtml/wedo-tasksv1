"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ActionError, requireActionUser } from "@/lib/auth";
import { runAction } from "@/lib/action-result";
import { audit } from "@/lib/events";
import { dateFromStr, todayDate } from "@/lib/dates";
import { firstRunOnOrAfter } from "@/lib/recurrence";
import { idSchema, optionalId, optionalText } from "@/lib/validation";

const schema = z
  .object({
    title: z.string().trim().min(1, "Title is required").max(180),
    description: optionalText(20000),
    clientId: optionalId,
    departmentId: optionalId,
    priorityId: idSchema,
    frequency: z.enum(["DAILY", "WEEKLY", "MONTHLY"]),
    weekday: z.coerce.number().int().min(0).max(6).nullable().optional(),
    monthDay: z.coerce.number().int().min(1).max(28).nullable().optional(),
    dueInDays: z.coerce.number().int().min(0).max(60).default(0),
    startOn: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional().or(z.literal("")),
    assigneeIds: z.array(idSchema).max(20).default([]),
    checklist: z.array(z.string().trim().min(1).max(500)).max(50).default([]),
  })
  .refine((d) => d.frequency !== "WEEKLY" || d.weekday != null, { message: "Pick a weekday", path: ["weekday"] })
  .refine((d) => d.frequency !== "MONTHLY" || d.monthDay != null, { message: "Pick a day of the month", path: ["monthDay"] });
export type RecurringInput = z.input<typeof schema>;

export async function saveRecurring(id: string | null, raw: RecurringInput) {
  return runAction(async () => {
    const me = await requireActionUser("recurring.manage");
    const d = schema.parse(raw);
    const users = d.assigneeIds.length ? await prisma.user.count({ where: { id: { in: d.assigneeIds }, isActive: true } }) : 0;
    if (users !== new Set(d.assigneeIds).size) throw new ActionError("One of the selected people is not an active user.");
    const today = todayDate();
    const from = d.startOn ? dateFromStr(d.startOn) : today;
    const nextRunOn = firstRunOnOrAfter(d, from < today ? today : from);
    const data = {
      title: d.title, description: d.description ?? null, clientId: d.clientId ?? null, departmentId: d.departmentId ?? null,
      priorityId: d.priorityId, frequency: d.frequency, weekday: d.frequency === "WEEKLY" ? d.weekday! : null,
      monthDay: d.frequency === "MONTHLY" ? d.monthDay! : null, dueInDays: d.dueInDays, checklist: d.checklist, nextRunOn,
    };
    const saved = id
      ? await prisma.recurringTask.update({ where: { id: idSchema.parse(id) }, data: { ...data, assignees: { deleteMany: {}, create: d.assigneeIds.map((userId) => ({ userId })) } } })
      : await prisma.recurringTask.create({ data: { ...data, createdById: me.id, assignees: { create: d.assigneeIds.map((userId) => ({ userId })) } } });
    await audit(me.id, id ? "recurring.update" : "recurring.create", "RecurringTask", saved.id, { title: d.title, frequency: d.frequency });
    revalidatePath("/recurring");
  });
}

export async function setRecurringActive(id: string, active: boolean) {
  return runAction(async () => {
    const me = await requireActionUser("recurring.manage");
    const r = await prisma.recurringTask.findUnique({ where: { id: idSchema.parse(id) } });
    if (!r) throw new ActionError("Not found.");
    const nextRunOn = active ? firstRunOnOrAfter(r, todayDate()) : r.nextRunOn;
    await prisma.recurringTask.update({ where: { id: r.id }, data: { isActive: z.boolean().parse(active), nextRunOn } });
    await audit(me.id, active ? "recurring.resume" : "recurring.pause", "RecurringTask", r.id, { title: r.title });
    revalidatePath("/recurring");
  });
}

export async function deleteRecurring(id: string) {
  return runAction(async () => {
    const me = await requireActionUser("recurring.manage");
    const r = await prisma.recurringTask.findUnique({ where: { id: idSchema.parse(id) } });
    if (!r) throw new ActionError("Not found.");
    await prisma.recurringTask.delete({ where: { id: r.id } }); // generated tasks are kept
    await audit(me.id, "recurring.delete", "RecurringTask", r.id, { title: r.title });
    revalidatePath("/recurring");
  });
}
