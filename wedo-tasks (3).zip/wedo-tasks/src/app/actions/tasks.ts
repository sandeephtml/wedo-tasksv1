"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import type { Prisma, TaskStatus } from "@prisma/client";
import { prisma } from "@/lib/db";
import { ActionError, can, requireActionUser, type CurrentUser } from "@/lib/auth";
import { runAction } from "@/lib/action-result";
import { audit, findApprovers, logActivity, notify } from "@/lib/events";
import { canEditTaskDetails, canWorkOnTask, isInvolved, visibleTasksWhere } from "@/lib/task-access";
import { checkStatusChange } from "@/lib/workflow";
import { dateFromStr, formatDay } from "@/lib/dates";
import { idSchema, taskInputSchema, urlSchema, optionalText, type TaskInput } from "@/lib/validation";

const refresh = () => revalidatePath("/", "layout");

const taskInclude = {
  status: true,
  assignees: { select: { userId: true } },
  collaborators: { select: { userId: true } },
} satisfies Prisma.TaskInclude;
type LoadedTask = Prisma.TaskGetPayload<{ include: typeof taskInclude }>;

async function loadTask(user: CurrentUser, id: string): Promise<LoadedTask> {
  const task = await prisma.task.findFirst({ where: { AND: [{ id: idSchema.parse(id) }, visibleTasksWhere(user)] }, include: taskInclude });
  if (!task) throw new ActionError("Task not found or you don't have access to it.");
  return task;
}

async function checkRefs(d: { priorityId?: string; statusId?: string | null; clientId?: string | null; departmentId?: string | null; userIds?: string[] }) {
  const [priority, status, client, dept, users] = await Promise.all([
    d.priorityId ? prisma.priority.count({ where: { id: d.priorityId } }) : 1,
    d.statusId ? prisma.taskStatus.count({ where: { id: d.statusId } }) : 1,
    d.clientId ? prisma.client.count({ where: { id: d.clientId } }) : 1,
    d.departmentId ? prisma.department.count({ where: { id: d.departmentId } }) : 1,
    d.userIds?.length ? prisma.user.count({ where: { id: { in: [...new Set(d.userIds)] }, isActive: true } }) : 0,
  ]);
  if (!priority) throw new ActionError("Unknown priority.");
  if (!status) throw new ActionError("Unknown status.");
  if (!client) throw new ActionError("Unknown client.");
  if (!dept) throw new ActionError("Unknown department.");
  if (d.userIds?.length && users !== new Set(d.userIds).size) throw new ActionError("One of the selected people is not an active user.");
}

async function nextPosition(statusId: string) {
  const agg = await prisma.task.aggregate({ where: { statusId }, _max: { position: true } });
  return (agg._max.position ?? 0) + 1024;
}

// ───────────── Create / update / delete ─────────────

export async function createTask(raw: TaskInput) {
  return runAction(async () => {
    const me = await requireActionUser("task.create");
    const d = taskInputSchema.parse(raw);
    let assigneeIds = [...new Set(d.assigneeIds)];
    if (!can(me, "task.assign") && assigneeIds.some((id) => id !== me.id)) {
      throw new ActionError("You can only assign tasks to yourself. Ask a manager to assign others.");
    }
    if (!assigneeIds.length && !can(me, "task.assign")) assigneeIds = [me.id];
    const collaboratorIds = [...new Set(d.collaboratorIds)].filter((id) => !assigneeIds.includes(id));
    await checkRefs({ ...d, userIds: [...assigneeIds, ...collaboratorIds] });

    const status = d.statusId
      ? await prisma.taskStatus.findUniqueOrThrow({ where: { id: d.statusId } })
      : await prisma.taskStatus.findFirst({ where: { isDefault: true } }) ?? (await prisma.taskStatus.findFirstOrThrow({ orderBy: { order: "asc" } }));
    if ((status.category === "DONE" || status.category === "REVISION") && !can(me, "task.approve")) {
      throw new ActionError("New tasks can't start as completed.");
    }

    const task = await prisma.$transaction(async (tx) => {
      const t = await tx.task.create({
        data: {
          title: d.title, description: d.description ?? null,
          clientId: d.clientId ?? null, departmentId: d.departmentId ?? null,
          priorityId: d.priorityId, statusId: status.id,
          startDate: d.startDate ? dateFromStr(d.startDate) : null,
          dueDate: d.dueDate ? dateFromStr(d.dueDate) : null,
          estimateHours: d.estimateHours ?? null,
          position: await nextPosition(status.id),
          createdById: me.id,
          completedAt: status.category === "DONE" ? new Date() : null,
          assignees: { create: assigneeIds.map((userId) => ({ userId })) },
          collaborators: { create: collaboratorIds.map((userId) => ({ userId })) },
          checklist: { create: d.checklist.map((text, order) => ({ text, order })) },
          links: { create: d.links.map((l) => ({ url: l.url, label: l.label ?? null, addedById: me.id })) },
        },
      });
      await logActivity({ type: "task.created", message: `created task "${t.title}"`, actorId: me.id, taskId: t.id, clientId: t.clientId }, tx);
      await notify(assigneeIds, { type: "ASSIGNED", title: `${me.name} assigned you "${t.title}"`, body: d.dueDate ? `Due ${formatDay(d.dueDate)}` : null, taskId: t.id, actorId: me.id }, tx);
      await notify(collaboratorIds, { type: "ASSIGNED", title: `${me.name} added you as a collaborator on "${t.title}"`, taskId: t.id, actorId: me.id }, tx);
      return t;
    });
    refresh();
    return { id: task.id };
  });
}

export async function updateTask(id: string, raw: TaskInput) {
  return runAction(async () => {
    const me = await requireActionUser();
    const task = await loadTask(me, id);
    if (!canEditTaskDetails(me, task)) throw new ActionError("Only the task creator or a manager can edit task details.");
    const d = taskInputSchema.parse(raw);

    const oldAssignees = task.assignees.map((a) => a.userId);
    const assigneeIds = [...new Set(d.assigneeIds)];
    const collaboratorIds = [...new Set(d.collaboratorIds)].filter((x) => !assigneeIds.includes(x));
    const oldCollabs = task.collaborators.map((c) => c.userId);
    const sameSet = (a: string[], b: string[]) => a.length === b.length && a.every((x) => b.includes(x));
    const assigneesChanged = !sameSet(oldAssignees, assigneeIds);
    if (assigneesChanged && !can(me, "task.assign")) throw new ActionError("You don't have permission to change assignees.");
    await checkRefs({ priorityId: d.priorityId, clientId: d.clientId, departmentId: d.departmentId, userIds: [...assigneeIds, ...collaboratorIds] });

    const changes: string[] = [];
    if (task.title !== d.title) changes.push("title");
    if ((task.description ?? null) !== (d.description ?? null)) changes.push("description");
    if (task.priorityId !== d.priorityId) changes.push("priority");
    if ((task.clientId ?? null) !== (d.clientId ?? null)) changes.push("client");
    if ((task.departmentId ?? null) !== (d.departmentId ?? null)) changes.push("department");
    const due = d.dueDate ? dateFromStr(d.dueDate) : null;
    const start = d.startDate ? dateFromStr(d.startDate) : null;
    if ((task.dueDate?.getTime() ?? null) !== (due?.getTime() ?? null)) changes.push("due date");
    if ((task.startDate?.getTime() ?? null) !== (start?.getTime() ?? null)) changes.push("start date");
    if ((task.estimateHours ?? null) !== (d.estimateHours ?? null)) changes.push("estimate");
    if (assigneesChanged) changes.push("assignees");
    if (!sameSet(oldCollabs, collaboratorIds)) changes.push("collaborators");

    await prisma.$transaction(async (tx) => {
      await tx.task.update({
        where: { id: task.id },
        data: {
          title: d.title, description: d.description ?? null, priorityId: d.priorityId,
          clientId: d.clientId ?? null, departmentId: d.departmentId ?? null,
          dueDate: due, startDate: start, estimateHours: d.estimateHours ?? null,
          assignees: { deleteMany: {}, create: assigneeIds.map((userId) => ({ userId })) },
          collaborators: { deleteMany: {}, create: collaboratorIds.map((userId) => ({ userId })) },
        },
      });
      if (changes.length) {
        await logActivity({ type: "task.updated", message: `updated ${changes.join(", ")} on "${d.title}"`, actorId: me.id, taskId: task.id, clientId: d.clientId ?? task.clientId }, tx);
      }
      const added = assigneeIds.filter((x) => !oldAssignees.includes(x));
      await notify(added, { type: "ASSIGNED", title: `${me.name} assigned you "${d.title}"`, taskId: task.id, actorId: me.id }, tx);
      const addedCollabs = collaboratorIds.filter((x) => !oldCollabs.includes(x));
      await notify(addedCollabs, { type: "ASSIGNED", title: `${me.name} added you as a collaborator on "${d.title}"`, taskId: task.id, actorId: me.id }, tx);
    });
    refresh();
  });
}

export async function setTaskAssignees(id: string, userIds: string[]) {
  return runAction(async () => {
    const me = await requireActionUser("task.assign");
    const task = await loadTask(me, id);
    const ids = [...new Set(z.array(idSchema).max(30).parse(userIds))];
    await checkRefs({ userIds: ids });
    const old = task.assignees.map((a) => a.userId);
    await prisma.$transaction(async (tx) => {
      await tx.task.update({ where: { id: task.id }, data: { assignees: { deleteMany: {}, create: ids.map((userId) => ({ userId })) } } });
      // An assignee shouldn't also be listed as a collaborator.
      await tx.taskCollaborator.deleteMany({ where: { taskId: task.id, userId: { in: ids } } });
      const names = ids.length ? (await tx.user.findMany({ where: { id: { in: ids } }, select: { name: true } })).map((u) => u.name).join(", ") : "nobody";
      await logActivity({ type: "task.assigned", message: `assigned "${task.title}" to ${names}`, actorId: me.id, taskId: task.id, clientId: task.clientId }, tx);
      await notify(ids.filter((x) => !old.includes(x)), { type: "ASSIGNED", title: `${me.name} assigned you "${task.title}"`, taskId: task.id, actorId: me.id }, tx);
    });
    refresh();
  });
}

export async function deleteTask(id: string) {
  return runAction(async () => {
    const me = await requireActionUser("task.delete");
    const task = await loadTask(me, id);
    await prisma.$transaction(async (tx) => {
      await tx.task.delete({ where: { id: task.id } });
      await audit(me.id, "task.delete", "Task", task.id, { number: task.number, title: task.title }, tx);
      if (task.clientId) await logActivity({ type: "task.deleted", message: `deleted task "${task.title}"`, actorId: me.id, clientId: task.clientId }, tx);
    });
    refresh();
  });
}

// ───────────── Status workflow ─────────────

async function applyStatusChange(me: CurrentUser, task: LoadedTask, to: TaskStatus, comment: string | null, position?: number) {
  if (task.statusId === to.id) {
    if (position !== undefined) await prisma.task.update({ where: { id: task.id }, data: { position } });
    return;
  }
  const err = checkStatusChange(
    { canApprove: can(me, "task.approve"), canEditAny: can(me, "task.edit_any"), isInvolved: isInvolved(me, task) },
    task.status.category,
    to.category,
    comment,
  );
  if (err) throw new ActionError(err);
  const assigneeIds = task.assignees.map((a) => a.userId);
  const watchers = [...assigneeIds, ...task.collaborators.map((c) => c.userId), task.createdById];

  await prisma.$transaction(async (tx) => {
    await tx.task.update({
      where: { id: task.id },
      data: {
        statusId: to.id,
        position: position ?? (await nextPosition(to.id)),
        completedAt: to.category === "DONE" ? new Date() : null,
      },
    });
    if (comment?.trim()) {
      await tx.comment.create({
        data: { taskId: task.id, authorId: me.id, body: comment.trim(), kind: to.category === "REVISION" ? "revision" : to.category === "DONE" ? "approval" : "comment" },
      });
    }
    const verb =
      to.category === "REVIEW" ? `submitted "${task.title}" for review`
      : to.category === "DONE" && task.status.category === "REVIEW" ? `approved "${task.title}"`
      : to.category === "REVISION" ? `requested revisions on "${task.title}"`
      : `moved "${task.title}" from ${task.status.name} to ${to.name}`;
    await logActivity({ type: `task.status`, message: verb, actorId: me.id, taskId: task.id, clientId: task.clientId }, tx);

    if (to.category === "REVIEW") {
      const approvers = await findApprovers(task.departmentId, tx);
      await notify(approvers, { type: "SUBMITTED", title: `${me.name} submitted "${task.title}" for review`, taskId: task.id, actorId: me.id }, tx);
    } else if (to.category === "DONE") {
      await notify(watchers, { type: "APPROVED", title: `${me.name} approved "${task.title}"`, body: comment, taskId: task.id, actorId: me.id }, tx);
    } else if (to.category === "REVISION") {
      await notify(assigneeIds.length ? assigneeIds : [task.createdById], { type: "REVISION", title: `${me.name} requested revisions on "${task.title}"`, body: comment, taskId: task.id, actorId: me.id }, tx);
    }
  });
}

export async function changeTaskStatus(id: string, statusId: string, comment?: string | null) {
  return runAction(async () => {
    const me = await requireActionUser();
    const task = await loadTask(me, id);
    const to = await prisma.taskStatus.findUnique({ where: { id: idSchema.parse(statusId) } });
    if (!to) throw new ActionError("Unknown status.");
    await applyStatusChange(me, task, to, optionalText(5000).parse(comment) ?? null);
    refresh();
  });
}

/** Board drag & drop: new column and position (the client computes the midpoint between neighbours). */
export async function moveTask(id: string, statusId: string, position: number, comment?: string | null) {
  return runAction(async () => {
    const me = await requireActionUser();
    const task = await loadTask(me, id);
    const pos = z.number().finite().parse(position);
    const to = await prisma.taskStatus.findUnique({ where: { id: idSchema.parse(statusId) } });
    if (!to) throw new ActionError("Unknown status.");
    if (to.id === task.statusId && !canWorkOnTask(me, task) && !can(me, "task.approve")) {
      throw new ActionError("Only people working on this task can reorder it.");
    }
    await applyStatusChange(me, task, to, optionalText(5000).parse(comment) ?? null, pos);
    refresh();
  });
}

// ───────────── Checklist & links ─────────────

async function loadWorkable(me: CurrentUser, taskId: string) {
  const task = await loadTask(me, taskId);
  if (!canWorkOnTask(me, task)) throw new ActionError("Only people working on this task can change it.");
  return task;
}

export async function addChecklistItem(taskId: string, text: string) {
  return runAction(async () => {
    const me = await requireActionUser();
    const task = await loadWorkable(me, taskId);
    const t = z.string().trim().min(1, "Enter the item text").max(500).parse(text);
    const count = await prisma.checklistItem.count({ where: { taskId: task.id } });
    if (count >= 100) throw new ActionError("A task can have at most 100 checklist items.");
    await prisma.checklistItem.create({ data: { taskId: task.id, text: t, order: count } });
    refresh();
  });
}

export async function toggleChecklistItem(itemId: string, done: boolean) {
  return runAction(async () => {
    const me = await requireActionUser();
    const item = await prisma.checklistItem.findUnique({ where: { id: idSchema.parse(itemId) } });
    if (!item) throw new ActionError("Checklist item not found.");
    const task = await loadWorkable(me, item.taskId);
    await prisma.checklistItem.update({ where: { id: item.id }, data: { done: z.boolean().parse(done) } });
    if (done) await logActivity({ type: "task.checklist", message: `checked "${item.text}" on "${task.title}"`, actorId: me.id, taskId: task.id });
    refresh();
  });
}

export async function deleteChecklistItem(itemId: string) {
  return runAction(async () => {
    const me = await requireActionUser();
    const item = await prisma.checklistItem.findUnique({ where: { id: idSchema.parse(itemId) } });
    if (!item) throw new ActionError("Checklist item not found.");
    await loadWorkable(me, item.taskId);
    await prisma.checklistItem.delete({ where: { id: item.id } });
    refresh();
  });
}

export async function addTaskLink(taskId: string, url: string, label?: string) {
  return runAction(async () => {
    const me = await requireActionUser();
    const task = await loadWorkable(me, taskId);
    const u = urlSchema.parse(url);
    const l = optionalText(200).parse(label) ?? null;
    await prisma.taskLink.create({ data: { taskId: task.id, url: u, label: l, addedById: me.id } });
    await logActivity({ type: "task.link", message: `added a link to "${task.title}"`, actorId: me.id, taskId: task.id });
    refresh();
  });
}

export async function deleteTaskLink(linkId: string) {
  return runAction(async () => {
    const me = await requireActionUser();
    const link = await prisma.taskLink.findUnique({ where: { id: idSchema.parse(linkId) } });
    if (!link) throw new ActionError("Link not found.");
    await loadWorkable(me, link.taskId);
    await prisma.taskLink.delete({ where: { id: link.id } });
    refresh();
  });
}
