"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { ActionError, requireActionUser } from "@/lib/auth";
import { runAction } from "@/lib/action-result";
import { audit, logActivity } from "@/lib/events";
import { clientInputSchema, idSchema, type ClientInput } from "@/lib/validation";

const STATUS_LABEL = { ACTIVE: "Active", ON_HOLD: "On hold", UPCOMING: "Upcoming" } as const;

function uniqueError(e: unknown): never {
  if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") throw new ActionError("A client with that name already exists.");
  throw e;
}

export async function createClient(raw: ClientInput) {
  return runAction(async () => {
    const me = await requireActionUser("client.manage");
    const d = clientInputSchema.parse(raw);
    const client = await prisma.$transaction(async (tx) => {
      const c = await tx.client.create({ data: { ...d, website: d.website ?? null, notes: d.notes ?? null } }).catch(uniqueError);
      await audit(me.id, "client.create", "Client", c.id, { name: c.name, status: c.status }, tx);
      await logActivity({ type: "client.created", message: `added client ${c.name}`, actorId: me.id, clientId: c.id }, tx);
      return c;
    });
    revalidatePath("/", "layout");
    return { id: client.id };
  });
}

export async function updateClient(id: string, raw: ClientInput) {
  return runAction(async () => {
    const me = await requireActionUser("client.manage");
    const d = clientInputSchema.parse(raw);
    const before = await prisma.client.findUnique({ where: { id: idSchema.parse(id) } });
    if (!before) throw new ActionError("Client not found.");
    await prisma.$transaction(async (tx) => {
      await tx.client.update({ where: { id: before.id }, data: { ...d, website: d.website ?? null, notes: d.notes ?? null } }).catch(uniqueError);
      await audit(me.id, "client.update", "Client", before.id, { before: { name: before.name, status: before.status, website: before.website, services: before.services }, after: d }, tx);
      const msg = before.status !== d.status ? `changed ${d.name} status from ${STATUS_LABEL[before.status]} to ${STATUS_LABEL[d.status]}` : `updated client ${d.name}`;
      await logActivity({ type: "client.updated", message: msg, actorId: me.id, clientId: before.id }, tx);
    });
    revalidatePath("/", "layout");
  });
}

export async function setClientStatus(id: string, status: "ACTIVE" | "ON_HOLD" | "UPCOMING") {
  return runAction(async () => {
    const me = await requireActionUser("client.manage");
    const s = z.enum(["ACTIVE", "ON_HOLD", "UPCOMING"]).parse(status);
    const before = await prisma.client.findUnique({ where: { id: idSchema.parse(id) } });
    if (!before) throw new ActionError("Client not found.");
    if (before.status === s) return;
    await prisma.$transaction(async (tx) => {
      await tx.client.update({ where: { id: before.id }, data: { status: s } });
      await audit(me.id, "client.status", "Client", before.id, { from: before.status, to: s }, tx);
      await logActivity({ type: "client.updated", message: `changed ${before.name} status from ${STATUS_LABEL[before.status]} to ${STATUS_LABEL[s]}`, actorId: me.id, clientId: before.id }, tx);
    });
    revalidatePath("/", "layout");
  });
}
