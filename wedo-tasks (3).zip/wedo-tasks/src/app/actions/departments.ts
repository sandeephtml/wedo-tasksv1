"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { ActionError, requireActionUser } from "@/lib/auth";
import { runAction } from "@/lib/action-result";
import { audit } from "@/lib/events";
import { hexColor, idSchema, optionalText } from "@/lib/validation";

const schema = z.object({ name: z.string().trim().min(1, "Name is required").max(80), color: hexColor, description: optionalText(500) });

const dup = (e: unknown): never => {
  if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") throw new ActionError("A department with that name already exists.");
  throw e;
};

export async function saveDepartment(id: string | null, raw: z.input<typeof schema>) {
  return runAction(async () => {
    const me = await requireActionUser("department.manage");
    const d = schema.parse(raw);
    const data = { ...d, description: d.description ?? null };
    const dep = id
      ? await prisma.department.update({ where: { id: idSchema.parse(id) }, data }).catch(dup)
      : await prisma.department.create({ data }).catch(dup);
    await audit(me.id, id ? "department.update" : "department.create", "Department", dep.id, d);
    revalidatePath("/", "layout");
  });
}

export async function deleteDepartment(id: string) {
  return runAction(async () => {
    const me = await requireActionUser("department.manage");
    const dep = await prisma.department.findUnique({ where: { id: idSchema.parse(id) }, include: { _count: { select: { tasks: true, members: true } } } });
    if (!dep) throw new ActionError("Department not found.");
    await prisma.$transaction(async (tx) => {
      await tx.department.delete({ where: { id: dep.id } }); // tasks keep existing with no department
      await audit(me.id, "department.delete", "Department", dep.id, { name: dep.name, tasks: dep._count.tasks, members: dep._count.members }, tx);
    });
    revalidatePath("/", "layout");
  });
}
