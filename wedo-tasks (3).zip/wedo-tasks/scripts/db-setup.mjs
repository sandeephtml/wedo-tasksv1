// Runs during deploy builds: applies migrations and the idempotent seed.
// It NEVER fails the build — if the database isn't configured yet, the site still deploys and
// /api/health explains what's missing. Problems are printed loudly in the build log.
import { spawnSync } from "node:child_process";

const line = "=".repeat(78);
const warn = (msg) => console.warn(`\n${line}\n  DATABASE SETUP SKIPPED: ${msg}\n  The site will still deploy. Fix the setting, then redeploy.\n  After deploying, open /api/health to check.\n${line}\n`);

const db = process.env.DATABASE_URL ?? "";
const direct = process.env.DIRECT_URL ?? "";
if (!db || !direct) {
  warn(`${!db ? "DATABASE_URL" : "DIRECT_URL"} is not set for builds (check its Scopes include "Builds").`);
  process.exit(0);
}
if (/YOUR_NEON_PASSWORD|\*\*\*\*/.test(db + direct)) {
  warn("a database URL still contains a placeholder instead of your real Neon password.");
  process.exit(0);
}

const run = (args) => spawnSync("npx", args, { stdio: "inherit", env: process.env, shell: process.platform === "win32" });

console.log("Applying database migrations…");
if (run(["prisma", "migrate", "deploy"]).status !== 0) {
  warn("`prisma migrate deploy` failed — see the Prisma error above (usually a wrong password/host in DIRECT_URL).");
  process.exit(0);
}
console.log("Seeding reference data (safe to repeat)…");
if (run(["tsx", "prisma/seed.ts"]).status !== 0) {
  warn("the seed failed — see the error above.");
  process.exit(0);
}
console.log("Database ready.");
