import { describe, expect, it } from "vitest";
import { firstRunOnOrAfter, nextRunAfter } from "@/lib/recurrence";
import { dateFromStr } from "@/lib/dates";

const d = dateFromStr;
const iso = (x: Date) => x.toISOString().slice(0, 10);

describe("recurrence", () => {
  it("daily runs every day", () => {
    expect(iso(firstRunOnOrAfter({ frequency: "DAILY" }, d("2026-10-31")))).toBe("2026-10-31");
    expect(iso(nextRunAfter({ frequency: "DAILY" }, d("2026-10-31")))).toBe("2026-11-01");
  });
  it("weekly lands on the chosen weekday", () => {
    // 2026-10-31 is a Saturday; Monday = 1
    expect(iso(firstRunOnOrAfter({ frequency: "WEEKLY", weekday: 1 }, d("2026-10-31")))).toBe("2026-11-02");
    expect(iso(firstRunOnOrAfter({ frequency: "WEEKLY", weekday: 6 }, d("2026-10-31")))).toBe("2026-10-31");
    expect(iso(nextRunAfter({ frequency: "WEEKLY", weekday: 6 }, d("2026-10-31")))).toBe("2026-11-07");
  });
  it("monthly lands on the chosen day and rolls over months and years", () => {
    expect(iso(firstRunOnOrAfter({ frequency: "MONTHLY", monthDay: 1 }, d("2026-10-31")))).toBe("2026-11-01");
    expect(iso(firstRunOnOrAfter({ frequency: "MONTHLY", monthDay: 31 }, d("2026-10-15")))).toBe("2026-10-28"); // clamped to 28
    expect(iso(nextRunAfter({ frequency: "MONTHLY", monthDay: 15 }, d("2026-12-15")))).toBe("2027-01-15");
  });
});
