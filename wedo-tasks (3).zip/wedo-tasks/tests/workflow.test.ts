import { describe, expect, it } from "vitest";
import { checkStatusChange } from "@/lib/workflow";

const member = { canApprove: false, canEditAny: false, isInvolved: true };
const outsider = { canApprove: false, canEditAny: false, isInvolved: false };
const manager = { canApprove: true, canEditAny: true, isInvolved: false };

describe("review workflow", () => {
  it("lets an involved member move between working statuses and submit for review", () => {
    expect(checkStatusChange(member, "OPEN", "OPEN")).toBeNull();
    expect(checkStatusChange(member, "OPEN", "REVIEW")).toBeNull();
    expect(checkStatusChange(member, "REVISION", "REVIEW")).toBeNull();
  });
  it("stops members completing their own task", () => {
    expect(checkStatusChange(member, "OPEN", "DONE")).toMatch(/review/i);
    expect(checkStatusChange(member, "REVIEW", "DONE")).not.toBeNull();
  });
  it("locks a task under review for non-approvers", () => {
    expect(checkStatusChange(member, "REVIEW", "OPEN")).toMatch(/waiting for review/i);
  });
  it("only approvers can request revisions, and a comment is required", () => {
    expect(checkStatusChange(member, "REVIEW", "REVISION", "fix")).not.toBeNull();
    expect(checkStatusChange(manager, "REVIEW", "REVISION")).toMatch(/comment/i);
    expect(checkStatusChange(manager, "REVIEW", "REVISION", "   ")).toMatch(/comment/i);
    expect(checkStatusChange(manager, "REVIEW", "REVISION", "Add competitor data")).toBeNull();
  });
  it("lets approvers approve and reopen", () => {
    expect(checkStatusChange(manager, "REVIEW", "DONE")).toBeNull();
    expect(checkStatusChange(manager, "DONE", "OPEN")).toBeNull();
    expect(checkStatusChange(member, "DONE", "OPEN")).toMatch(/reopen/i);
  });
  it("blocks people not working on the task", () => {
    expect(checkStatusChange(outsider, "OPEN", "REVIEW")).toMatch(/working on this task/i);
  });
});
