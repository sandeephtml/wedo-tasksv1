# WeDo Tasks

The internal task and to-do platform for **WedoMarketing** (wedomarketing.io): clients, departments,
Asana-style tasks with a review workflow, a Kanban board, recurring tasks, notifications, a founders'
dashboard and reports.

**Stack:** Next.js 15 (App Router) · TypeScript · Tailwind CSS · Prisma + PostgreSQL (Neon) ·
jose-signed HttpOnly session cookies · bcrypt · zod · dnd-kit · lucide-react.
Serverless-ready: no `output: "standalone"`, no local file storage, no in-memory state.

---

## Features

| Area | What it does |
| --- | --- |
| **Auth** | Email + password (bcrypt, cost 12). Signed HttpOnly cookie (7 days). Middleware guards every page, and every page and server action re-checks the user in the database. Login rate limit: 5 failures per 15 min per email. A password reset or deactivation signs the user out everywhere. Temporary passwords must be changed at first sign-in. |
| **Roles** | Super Admin, Admin, Department Manager, Team Member. Permissions are database rows, edited in **Settings → Roles & permissions**. Only the Super Admin can create or manage admin accounts. The last active Super Admin can't be deactivated or demoted. |
| **Visibility** | Founders (`task.view_all`) see everything. Everyone else sees tasks they're assigned to, collaborate on or created, plus tasks in their departments. |
| **Team** | Create logins (temp password shown once), edit role and departments (people can be in several), reset password, deactivate/reactivate. Everyone can change their own password under **My account**. |
| **Clients** | Active / On hold / Upcoming, website, services, notes. The profile shows counts (total, pending, in progress, done, overdue), tasks and activity. |
| **Tasks** | Title, description, client (optional), department, multiple assignees, collaborators, priority, status, start/due dates, estimate, checklist, comments with @mentions, links (Google Drive etc.), activity history. |
| **Views** | List grouped by priority (inline status and assignee changes, overdue in red, show-completed toggle). Drag-and-drop board with optimistic updates and rollback. Filters: client, department, priority, assignee, due date. Search. **My Tasks**. |
| **Review workflow** | Members submit for review. Only approvers (`task.approve`) can approve (Completed) or request a revision, which needs a comment. Members can't complete their own tasks or move a task out of review. |
| **Statuses & priorities** | Database rows, editable in Settings (name, colour, order, default). Each status has a workflow category: Working, Review, Revision or Completed. |
| **Recurring tasks** | Daily, weekly or monthly templates. A daily cron creates the tasks and is idempotent, so a double run can't create duplicates. |
| **Notifications** | Bell with unread count for assigned, mentioned, commented, submitted, approved, revision and overdue. Overdue alerts are sent once per task per due date. |
| **Dashboard** | Active clients, team size, total/pending/in-progress/review/completed/overdue tasks, department completion %, team performance, upcoming deadlines (today, tomorrow, later this week, next week), activity feed. Everything comes from the database. |
| **Reports** | By client, department and member, with date filters. CSV export (protected against spreadsheet formula injection). |
| **Audit log** | Logins created, password resets, deactivations, role and permission changes, client edits, settings changes, deletions and exports. |

### Re-theming
Every colour, font, radius and shadow lives in **`src/app/theme.css`**. Change the values there; no
component code needs to change.

---

## Local development

```bash
cp .env.example .env          # fill in DATABASE_URL, DIRECT_URL, AUTH_SECRET, CRON_SECRET
npm install
npx prisma migrate deploy     # or: npm run db:migrate (creates new migrations in dev)
npm run db:seed               # prints any generated passwords ONCE
npm run dev                   # http://localhost:3000
```

Checks: `npm run typecheck`, `npm run lint`, `npm test`, `npm run build`.

---

## Deployment (Neon + GitHub + Vercel)

### 1. Create the Neon database
1. Sign in at <https://console.neon.tech> and click **New project**. Name it `wedo-tasks` and pick the region closest to your team (e.g. *AWS Asia Pacific (Singapore)* for India).
2. On the project dashboard, open **Connect**:
   - Turn **Connection pooling ON** and copy the string. This is `DATABASE_URL` (the host contains `-pooler`). Add `&pgbouncer=true&connect_timeout=15` to the end.
   - Turn **Connection pooling OFF** and copy the string. This is `DIRECT_URL`.

### 2. Push the code to GitHub
```bash
cd wedo-tasks
git remote add origin https://github.com/<your-org>/wedo-tasks.git
git push -u origin main
```
(Create the empty **private** repo on GitHub first.)

### 3. Create the tables and seed data (run once, from your computer)
```bash
export DATABASE_URL="<pooled url>"
export DIRECT_URL="<direct url>"
npx prisma migrate deploy
SEED_SUPER_ADMIN_PASSWORD="<choose a strong one>" SEED_ADMIN_PASSWORD="<choose a strong one>" npm run db:seed
```
The seed creates roles and permissions, statuses, priorities, departments, all clients and the team.
Founders get the passwords you pass in (or random ones if you leave them empty). Every team member
gets a random temporary password, **printed once**. Copy them now and share them privately. The
seed is safe to re-run: it never overwrites existing passwords or your permission edits.

### 4. Import into Vercel
1. <https://vercel.com/new> → **Import** the GitHub repo. Framework: *Next.js* (auto-detected). Keep the default build command (`npm run build` runs `prisma generate` first).
2. Under **Environment Variables** (Production and Preview), add:

| Name | Value |
| --- | --- |
| `DATABASE_URL` | pooled Neon URL |
| `DIRECT_URL` | direct Neon URL |
| `AUTH_SECRET` | output of `openssl rand -hex 32` |
| `CRON_SECRET` | output of `openssl rand -hex 24` |
| `APP_TIMEZONE` | `Asia/Kolkata` |

   The `SEED_*` variables are only needed where you run the seed (step 3). You don't need them in Vercel.
3. Click **Deploy**.
4. The cron in `vercel.json` runs `/api/cron/daily` every day at 00:30 UTC (06:00 IST). Vercel sends `Authorization: Bearer $CRON_SECRET` automatically. Check it under **Project → Settings → Cron Jobs**. To trigger it by hand:
   ```bash
   curl -H "Authorization: Bearer $CRON_SECRET" https://<your-domain>/api/cron/daily
   ```
5. For future schema changes, run `npx prisma migrate deploy` (with `DIRECT_URL` set) before or right after deploying.

### 5. Custom domain
Vercel → **Project → Settings → Domains** → add e.g. `tasks.wedomarketing.io`. At your DNS provider,
add a **CNAME** record `tasks` → `cname.vercel-dns.com` (Vercel shows the exact value). HTTPS is issued
automatically.

### Alternative: Netlify
1. **Add new site → Import from Git**, then select the repo (or drag-and-drop deploy). `netlify.toml` already sets the Next.js runtime, and its build runs `scripts/db-setup.mjs` (migrations + idempotent seed) first. That step never fails the deploy: if the database isn't configured it prints why and the site still deploys; check `/api/health`. Team passwords appear once in the deploy log.
2. Add the same environment variables under **Site configuration → Environment variables**.
3. `netlify/functions/daily-cron.mts` is a scheduled function that calls `/api/cron/daily` at 00:30 UTC using `CRON_SECRET`.
4. For the domain: **Domain management → Add a domain**, then point a CNAME at your `*.netlify.app` host.

---

## Troubleshooting
Open `https://<your-site>/api/health`. It reports missing settings, whether the database is reachable, and whether tables and users exist. It never shows secret values.

## Project layout
```
prisma/            schema.prisma, migrations, seed.ts
src/app/(auth)/    login
src/app/(app)/     dashboard, my-tasks, tasks, clients, team, departments, recurring, reports, settings, account
src/app/actions/   server actions (every one validates with zod and checks permissions)
src/app/api/       cron + CSV export route handlers
src/lib/           auth/session, permissions, task access rules, workflow, recurrence, reports, dates
src/components/    shell, tasks (list, board, forms), ui kit
src/app/theme.css  all theme tokens
tests/             unit tests (vitest)
```

## Not in v1
- File uploads. Attachments are links only (Google Drive / reference URLs).
- Email or push notifications. They're in-app only.
- Time tracking beyond the estimate field.
